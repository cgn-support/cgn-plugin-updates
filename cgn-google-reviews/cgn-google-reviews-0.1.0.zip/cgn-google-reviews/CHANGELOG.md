## 0.1.0
- Reviews post type that holds the site's Google reviews, synced by CGN's scheduled job through a secure REST endpoint.
- Rules on Reviews → Settings: minimum rating, text required, how many to show, newest first. Reviews that don't qualify stay as drafts.
- Reviewer names as "First L." by default, review dates in a chosen format, and the owner's reply with a label.
- Every field works with Elementor's Post Custom Field dynamic tag, plus a [cgn_review] shortcode for the reply.
