# CGN Google Reviews

Keeps a site's Google reviews as WordPress posts so a designer can show them in any layout with an Elementor loop. The plugin stores, filters and formats reviews. It does not fetch them: CGN's scheduled job reads the client's Google Business Profile and sends the full list to the site.

## Setting up a site

1. Install the plugin from the update feed zip (see the repo README) and activate it.
2. Reviews → Settings: pick the rules. Defaults are 5-star reviews with text, every one that qualifies, newest first, names as "First L.", dates as "Sep 30, 2026". Set the owner reply label, for example "Lex, owner, replied:".
3. Make sure the site has an administrator application password in `clients.json`, and add the client to the review sync job.
4. In Elementor, build a Loop on the "Reviews" post type ordered by date, newest first, and bind the card text to dynamic tags (below).

## Fields for Elementor

| What | Dynamic tag |
|---|---|
| Review text | Post Content |
| Reviewer name ("Sarah M.") | Post Title, or Post Custom Field `reviewer_name` |
| Avatar letter | Post Custom Field `reviewer_initial` |
| Stars ("★★★★★") | Post Custom Field `review_stars` |
| Rating (1 to 5) | Post Custom Field `review_rating` |
| Review date | Post Custom Field `review_date`, or Post Date |
| Source ("Google") | Post Custom Field `review_source` |
| Owner reply with bold label | Shortcode `[cgn_review field="reply"]` (prints nothing when there's no reply, so `:empty` hides the box) |
| Owner reply text only | Post Custom Field `owner_reply` |

## Sync contract

`POST /wp-json/cgn-google-reviews/v1/sync`, authenticated as an administrator with an application password.

```json
{
  "source": "google",
  "replace": true,
  "reviews": [ /* every review, newest or oldest first, either shape below */ ]
}
```

Each review can be sent exactly as the Google Business Profile API returns it (`reviewId`, `reviewer.displayName`, `starRating`, `comment`, `createTime`, `updateTime`, `reviewReply`), or in a simple shape: `id`, `author`, `rating` (1 to 5), `text`, `created`, `updated`, `reply`.

- Reviews are matched by ID, so re-sending the same list changes nothing.
- With `replace` on (the default), reviews missing from the list were deleted on Google and go to the Trash. Always send the full list.
- An empty list is refused unless `allow_empty` is true, so a failed fetch can't wipe the section.
- A review someone moves to the Trash by hand stays there after later syncs.
- Machine translations are stripped, keeping the reviewer's own words.

`GET /wp-json/cgn-google-reviews/v1/status` returns the last sync's counts, how many reviews are shown and hidden, and the current settings.
