<?php
/**
 * Stores synced reviews and applies the display rules.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Repository {

	/** Google's starRating values. */
	const STAR_WORDS = array(
		'ONE'   => 1,
		'TWO'   => 2,
		'THREE' => 3,
		'FOUR'  => 4,
		'FIVE'  => 5,
	);

	/**
	 * Saves a full set of reviews from one source, then re-applies the display rules.
	 *
	 * @param string $source  Source key, e.g. "google".
	 * @param array  $reviews Raw review objects (Google Business Profile shape or the simple shape, see normalize()).
	 * @param bool   $replace When true, reviews from this source that aren't in $reviews are moved to the Trash
	 *                        (they were deleted on Google). Send the full list every time when using it.
	 * @return array Counts: received, skipped, created, updated, removed, published, hidden.
	 */
	public static function sync( $source, array $reviews, $replace ) {
		$counts = array(
			'received' => count( $reviews ),
			'skipped'  => 0,
			'created'  => 0,
			'updated'  => 0,
			'removed'  => 0,
		);
		$seen   = array();

		foreach ( $reviews as $raw ) {
			$review = is_array( $raw ) ? self::normalize( $raw ) : null;
			if ( null === $review ) {
				++$counts['skipped'];
				continue;
			}
			$seen[ $review['id'] ] = true;
			$result                = self::upsert( $source, $review );
			if ( $result ) {
				++$counts[ $result ];
			}
		}

		if ( $replace ) {
			foreach ( self::posts_for_source( $source ) as $post_id => $source_id ) {
				if ( ! isset( $seen[ $source_id ] ) && 'trash' !== get_post_status( $post_id ) ) {
					wp_trash_post( $post_id );
					++$counts['removed'];
				}
			}
		}

		return array_merge( $counts, self::apply_rules() );
	}

	/**
	 * Accepts a review from the Google Business Profile API as-is, or a simple shape:
	 *   { id, author, rating (1-5), text, created (ISO 8601), updated, reply, reply_time }
	 *
	 * @param array $r Raw review.
	 * @return array|null Normalized review, or null when it has no ID.
	 */
	public static function normalize( array $r ) {
		$id = self::first( $r, array( 'reviewId', 'id', 'review_id' ) );
		if ( '' === $id ) {
			return null;
		}

		$author = isset( $r['reviewer']['displayName'] ) ? (string) $r['reviewer']['displayName'] : self::first( $r, array( 'author', 'reviewer_name' ) );

		$rating = 0;
		if ( isset( $r['starRating'] ) && isset( self::STAR_WORDS[ strtoupper( (string) $r['starRating'] ) ] ) ) {
			$rating = self::STAR_WORDS[ strtoupper( (string) $r['starRating'] ) ];
		} elseif ( isset( $r['rating'] ) ) {
			$rating = (int) $r['rating'];
		}

		$created = strtotime( self::first( $r, array( 'createTime', 'created', 'review_date' ) ) );
		$updated = strtotime( self::first( $r, array( 'updateTime', 'updated' ) ) );

		$reply      = isset( $r['reviewReply']['comment'] ) ? (string) $r['reviewReply']['comment'] : self::first( $r, array( 'reply', 'owner_reply' ) );
		$reply_time = isset( $r['reviewReply']['updateTime'] ) ? (string) $r['reviewReply']['updateTime'] : self::first( $r, array( 'reply_time' ) );

		return array(
			'id'         => substr( sanitize_text_field( $id ), 0, 191 ),
			'author'     => sanitize_text_field( $author ),
			'rating'     => max( 0, min( 5, $rating ) ),
			'text'       => self::clean_text( self::first( $r, array( 'comment', 'text', 'review_text' ) ) ),
			'created'    => $created ? $created : time(),
			'updated'    => $updated ? $updated : ( $created ? $created : time() ),
			'reply'      => self::clean_text( $reply ),
			'reply_time' => sanitize_text_field( $reply_time ),
		);
	}

	/**
	 * Google appends machine translations to the review text. Keep the reviewer's own words.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	public static function clean_text( $text ) {
		$text = (string) $text;
		if ( preg_match( '/\(Original\)\s*(.+)$/su', $text, $m ) ) {
			$text = $m[1];
		}
		$text = preg_replace( '/^\(Translated by Google\)\s*/u', '', $text );
		return trim( sanitize_textarea_field( $text ) );
	}

	/**
	 * @param string $source Source key.
	 * @param array  $review Normalized review.
	 * @return string|null "created", "updated", or null when nothing changed.
	 */
	private static function upsert( $source, array $review ) {
		$existing = self::find( $source, $review['id'] );
		$gmt      = gmdate( 'Y-m-d H:i:s', $review['created'] );

		$postarr = array(
			'post_type'     => Post_Type::NAME,
			'post_title'    => self::format_name( $review['author'], Plugin::setting( 'name_format' ) ),
			'post_content'  => $review['text'],
			'post_date_gmt' => $gmt,
			'post_date'     => get_date_from_gmt( $gmt ),
		);

		if ( $existing ) {
			if ( (int) get_post_meta( $existing, Post_Type::META_UPDATED, true ) === $review['updated']
				&& (string) get_post_meta( $existing, 'owner_reply', true ) === $review['reply'] ) {
				return null;
			}
			$postarr['ID'] = $existing;
			wp_update_post( wp_slash( $postarr ) );
			$post_id = $existing;
			$result  = 'updated';
		} else {
			$postarr['post_status'] = 'draft'; // apply_rules() publishes it if it qualifies.
			$post_id                = wp_insert_post( wp_slash( $postarr ) );
			if ( ! $post_id || is_wp_error( $post_id ) ) {
				return null;
			}
			$result = 'created';
		}

		update_post_meta( $post_id, Post_Type::META_SOURCE, $source );
		update_post_meta( $post_id, Post_Type::META_SOURCE_ID, $review['id'] );
		update_post_meta( $post_id, Post_Type::META_AUTHOR, $review['author'] );
		update_post_meta( $post_id, Post_Type::META_UPDATED, $review['updated'] );
		update_post_meta( $post_id, Post_Type::META_REPLY_TIME, $review['reply_time'] );
		update_post_meta( $post_id, 'review_rating', $review['rating'] );
		update_post_meta( $post_id, 'review_stars', str_repeat( '★', $review['rating'] ) );
		update_post_meta( $post_id, 'review_source', 'google' === $source ? 'Google' : ucfirst( $source ) );
		update_post_meta( $post_id, 'owner_reply', $review['reply'] );

		return $result;
	}

	/**
	 * Publishes the reviews that pass the rules on the settings screen, newest first up to
	 * the limit, and drafts the rest. Also refreshes the name and date fields, so changing
	 * a format on the settings screen updates every review.
	 *
	 * @return array Counts: published, hidden.
	 */
	public static function apply_rules() {
		$settings = Plugin::get_settings();
		$min      = max( 1, min( 5, (int) $settings['min_rating'] ) );
		$limit    = max( 0, (int) $settings['max_published'] );

		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$published = 0;
		$hidden    = 0;

		foreach ( $ids as $post_id ) {
			$rating = (int) get_post_meta( $post_id, 'review_rating', true );
			$text   = trim( (string) get_post_field( 'post_content', $post_id ) );

			$reason = '';
			if ( $rating < $min ) {
				$reason = 'rating';
			} elseif ( ! empty( $settings['require_text'] ) && '' === $text ) {
				$reason = 'no_text';
			} elseif ( $limit && $published >= $limit ) {
				$reason = 'limit';
			}

			$name   = self::format_name( (string) get_post_meta( $post_id, Post_Type::META_AUTHOR, true ), $settings['name_format'] );
			$status = '' === $reason ? 'publish' : 'draft';

			$update = array();
			if ( get_post_status( $post_id ) !== $status ) {
				$update['post_status'] = $status;
			}
			if ( get_the_title( $post_id ) !== $name ) {
				$update['post_title'] = $name;
			}
			if ( $update ) {
				$update['ID'] = $post_id;
				wp_update_post( wp_slash( $update ) );
			}

			update_post_meta( $post_id, 'reviewer_name', $name );
			update_post_meta( $post_id, 'reviewer_initial', self::initial( $name ) );
			update_post_meta( $post_id, 'review_date', get_the_date( $settings['date_format'], $post_id ) );
			update_post_meta( $post_id, Post_Type::META_HIDDEN, $reason );

			if ( '' === $reason ) {
				++$published;
			} else {
				++$hidden;
			}
		}

		return array(
			'published' => $published,
			'hidden'    => $hidden,
		);
	}

	/**
	 * @param string $name   Reviewer's display name from Google.
	 * @param string $format first_initial ("Sarah M."), first ("Sarah") or full ("Sarah Miller").
	 * @return string
	 */
	public static function format_name( $name, $format ) {
		$parts = preg_split( '/\s+/u', trim( (string) $name ), -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $parts ) {
			return __( 'Google reviewer', 'cgn-google-reviews' );
		}
		if ( 'full' === $format ) {
			return implode( ' ', $parts );
		}
		$first = self::upper_first( $parts[0] );
		if ( 'first' === $format || count( $parts ) < 2 ) {
			return $first;
		}
		$last = end( $parts );
		return $first . ' ' . self::upper_first( self::substr( $last, 0, 1 ) ) . '.';
	}

	/**
	 * @param string $name Formatted name.
	 * @return string
	 */
	public static function initial( $name ) {
		return self::upper_first( self::substr( trim( (string) $name ), 0, 1 ) );
	}

	/** @return array<int,string> Post ID => source review ID, every status including Trash. */
	private static function posts_for_source( $source ) {
		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => Post_Type::META_SOURCE, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $source, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		$out = array();
		foreach ( $ids as $post_id ) {
			$out[ $post_id ] = (string) get_post_meta( $post_id, Post_Type::META_SOURCE_ID, true );
		}
		return $out;
	}

	/**
	 * Finds a review by its source ID in any status, including Trash, so a review someone
	 * trashed by hand stays trashed when it syncs again.
	 *
	 * @return int Post ID, or 0.
	 */
	private static function find( $source, $source_id ) {
		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => array( 'publish', 'draft', 'trash' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'   => Post_Type::META_SOURCE_ID,
						'value' => $source_id,
					),
					array(
						'key'   => Post_Type::META_SOURCE,
						'value' => $source,
					),
				),
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * @param array $r    Raw review.
	 * @param array $keys Keys to try, in order.
	 * @return string First non-empty value.
	 */
	private static function first( array $r, array $keys ) {
		foreach ( $keys as $key ) {
			if ( isset( $r[ $key ] ) && is_scalar( $r[ $key ] ) && '' !== (string) $r[ $key ] ) {
				return (string) $r[ $key ];
			}
		}
		return '';
	}

	private static function substr( $text, $start, $length ) {
		return function_exists( 'mb_substr' ) ? mb_substr( $text, $start, $length ) : substr( $text, $start, $length );
	}

	private static function upper_first( $text ) {
		if ( ! function_exists( 'mb_strtoupper' ) ) {
			return ucfirst( $text );
		}
		return mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 );
	}
}
