<?php
/**
 * [cgn_review field="…"] prints one field of the current review inside a loop.
 *
 * Fields: name, initial, stars, rating, date, text, reply, reply_text, source.
 * "reply" prints the owner reply label in bold followed by the reply, and nothing
 * at all when the review has no reply, so an empty reply box can be hidden with
 * CSS (:empty). Optional "id" picks a specific review instead of the loop's.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Shortcode {

	const TAG = 'cgn_review';

	public static function init() {
		add_shortcode( self::TAG, array( __CLASS__, 'render' ) );
	}

	/**
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ) {
		$atts    = shortcode_atts(
			array(
				'field' => 'text',
				'id'    => 0,
			),
			$atts,
			self::TAG
		);
		$post_id = $atts['id'] ? (int) $atts['id'] : get_the_ID();
		if ( ! $post_id || Post_Type::NAME !== get_post_type( $post_id ) ) {
			return '';
		}

		switch ( sanitize_key( $atts['field'] ) ) {
			case 'name':
				return esc_html( (string) get_post_meta( $post_id, 'reviewer_name', true ) );
			case 'initial':
				return esc_html( (string) get_post_meta( $post_id, 'reviewer_initial', true ) );
			case 'stars':
				return esc_html( (string) get_post_meta( $post_id, 'review_stars', true ) );
			case 'rating':
				return esc_html( (string) (int) get_post_meta( $post_id, 'review_rating', true ) );
			case 'date':
				return esc_html( (string) get_post_meta( $post_id, 'review_date', true ) );
			case 'source':
				return esc_html( (string) get_post_meta( $post_id, 'review_source', true ) );
			case 'reply_text':
				return esc_html( (string) get_post_meta( $post_id, 'owner_reply', true ) );
			case 'reply':
				$reply = (string) get_post_meta( $post_id, 'owner_reply', true );
				if ( '' === $reply ) {
					return '';
				}
				$label = trim( (string) Plugin::setting( 'reply_label' ) );
				return ( '' === $label ? '' : '<strong>' . esc_html( $label ) . '</strong> ' ) . esc_html( $reply );
			case 'text':
			default:
				return esc_html( (string) get_post_field( 'post_content', $post_id ) );
		}
	}
}
