<?php
/**
 * Removes plugin data when the plugin is deleted from the Plugins screen:
 * every synced review, its fields, and the plugin's options.
 *
 * @package CGN_GR
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$cgn_gr_ids = get_posts(
	array(
		'post_type'      => 'cgn_review',
		'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'trash' ),
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	)
);
foreach ( $cgn_gr_ids as $cgn_gr_id ) {
	wp_delete_post( $cgn_gr_id, true );
}
unset( $cgn_gr_ids, $cgn_gr_id );

delete_option( 'cgn_gr_settings' );
delete_option( 'cgn_gr_sync_status' );
delete_option( 'external_updates-cgn-google-reviews' ); // Plugin Update Checker's state.
