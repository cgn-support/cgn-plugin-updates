<?php
/**
 * Plugin Name:       CGN Google Reviews
 * Description:       Keeps the site's Google Business Profile reviews as WordPress posts, filtered and formatted, so an Elementor loop can show them in any design. A scheduled CGN job sends the reviews.
 * Version:           0.2.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Contractor Growth Network
 * Text Domain:       cgn-google-reviews
 */

defined( 'ABSPATH' ) || exit;

define( 'CGN_GR_VERSION', '0.2.0' );
define( 'CGN_GR_FILE', __FILE__ );
define( 'CGN_GR_PATH', plugin_dir_path( __FILE__ ) );
define( 'CGN_GR_URL', plugin_dir_url( __FILE__ ) );

require_once CGN_GR_PATH . 'includes/class-plugin.php';
require_once CGN_GR_PATH . 'includes/class-post-type.php';
require_once CGN_GR_PATH . 'includes/class-repository.php';
require_once CGN_GR_PATH . 'includes/class-settings.php';
require_once CGN_GR_PATH . 'includes/class-rest.php';
require_once CGN_GR_PATH . 'includes/class-shortcode.php';

add_action( 'plugins_loaded', array( 'CGN_GR\\Plugin', 'instance' ) );

register_activation_hook( __FILE__, array( 'CGN_GR\\Plugin', 'activate' ) );

/*
 * Automatic updates from CGN's update feed.
 *
 * The cgn-plugins GitHub repo builds a new package whenever this file's Version
 * header changes and publishes it to the feed. The feed address below is filled
 * in by that build, so copies installed straight from the repo source (where the
 * placeholder is still in place) simply skip update checks.
 * To point a site at a different feed, define CGN_UPDATE_FEED in wp-config.php.
 */
$cgn_gr_feed = defined( 'CGN_UPDATE_FEED' ) ? CGN_UPDATE_FEED : 'https://cgn-support.github.io/cgn-plugin-updates';
if ( false === strpos( $cgn_gr_feed, '{{' ) ) {
	require_once CGN_GR_PATH . 'vendor/plugin-update-checker/plugin-update-checker.php';
	\YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		trailingslashit( $cgn_gr_feed ) . 'cgn-google-reviews/info.json',
		__FILE__,
		'cgn-google-reviews',
		6 // Check every 6 hours (WordPress's own check is every 12).
	);
}
unset( $cgn_gr_feed );
