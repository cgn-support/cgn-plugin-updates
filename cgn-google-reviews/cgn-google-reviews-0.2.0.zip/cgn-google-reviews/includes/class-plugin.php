<?php
/**
 * Plugin bootstrap and settings access.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** Option name holding all plugin settings. */
	const OPTION = 'cgn_gr_settings';

	/** Option name holding the result of the most recent sync. */
	const STATUS_OPTION = 'cgn_gr_sync_status';

	/** @var Plugin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		Post_Type::init();
		Settings::init();
		Rest::init();
		Shortcode::init();
	}

	/** Registers the post type before flushing so its admin screens work straight away. */
	public static function activate() {
		Post_Type::register();
		flush_rewrite_rules();
	}

	/**
	 * Defaults match the CGN standard: 5-star reviews that have text, newest first,
	 * every qualifying review shown, names as "First L.".
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'min_rating'    => 5,
			'require_text'  => 1,
			'max_published' => 0, // 0 = show every review that qualifies.
			'name_format'   => 'first_initial',
			'date_format'   => 'M j, Y',
		);
	}

	/** @return array */
	public static function get_settings() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * @param string $key Setting name.
	 * @return mixed
	 */
	public static function setting( $key ) {
		$settings = self::get_settings();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}
}
