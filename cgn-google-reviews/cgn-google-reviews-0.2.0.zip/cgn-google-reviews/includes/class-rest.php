<?php
/**
 * REST endpoints the CGN sync job calls, authenticated as a site administrator
 * (an application password).
 *
 * POST /wp-json/cgn-google-reviews/v1/sync
 *   { "source": "google", "reviews": [ ...every review... ], "replace": true }
 *   Reviews can be posted exactly as the Google Business Profile API returns them.
 *   With "replace" on (the default), reviews missing from the list are moved to the
 *   Trash, so send the full list every time. An empty list is refused unless
 *   "allow_empty" is true, so a failed fetch can't wipe the section.
 *
 * GET /wp-json/cgn-google-reviews/v1/status
 *   The last sync's counts and how many reviews are on the site.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Rest {

	const NS = 'cgn-google-reviews/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route(
			self::NS,
			'/sync',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'sync' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
				'args'                => array(
					'source'      => array(
						'type'              => 'string',
						'default'           => 'google',
						'sanitize_callback' => 'sanitize_key',
					),
					'reviews'     => array(
						'required' => true,
						'type'     => 'array',
					),
					'replace'     => array(
						'type'    => 'boolean',
						'default' => true,
					),
					'allow_empty' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => array( __CLASS__, 'can_manage' ),
			)
		);
	}

	public static function can_manage() {
		return current_user_can( 'manage_options' );
	}

	public static function sync( \WP_REST_Request $request ) {
		$reviews = $request['reviews'];
		if ( ! is_array( $reviews ) ) {
			return new \WP_Error( 'cgn_gr_bad_reviews', __( 'reviews must be a list.', 'cgn-google-reviews' ), array( 'status' => 400 ) );
		}
		if ( ! $reviews && ! $request['allow_empty'] ) {
			return new \WP_Error( 'cgn_gr_empty', __( 'The review list is empty. Nothing was changed. Send allow_empty to clear every review on purpose.', 'cgn-google-reviews' ), array( 'status' => 400 ) );
		}

		$source = $request['source'] ? $request['source'] : 'google';
		$counts = Repository::sync( $source, $reviews, (bool) $request['replace'] );

		$status = array_merge(
			$counts,
			array(
				'time'   => time(),
				'source' => $source,
			)
		);
		update_option( Plugin::STATUS_OPTION, $status, false );

		return rest_ensure_response( $status );
	}

	public static function status() {
		$counts = wp_count_posts( Post_Type::NAME );
		return rest_ensure_response(
			array(
				'last_sync' => get_option( Plugin::STATUS_OPTION, null ),
				'shown'     => isset( $counts->publish ) ? (int) $counts->publish : 0,
				'hidden'    => isset( $counts->draft ) ? (int) $counts->draft : 0,
				'trashed'   => isset( $counts->trash ) ? (int) $counts->trash : 0,
				'settings'  => Plugin::get_settings(),
				'version'   => CGN_GR_VERSION,
			)
		);
	}
}
