<?php
/**
 * Reviews → Settings admin screen.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Settings {

	const PAGE = 'cgn-google-reviews';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'update_option_' . Plugin::OPTION, array( __CLASS__, 'settings_changed' ) );
		add_action( 'add_option_' . Plugin::OPTION, array( __CLASS__, 'settings_changed' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CGN_GR_FILE ), array( __CLASS__, 'action_link' ) );
	}

	public static function add_page() {
		add_submenu_page(
			'edit.php?post_type=' . Post_Type::NAME,
			__( 'Review Settings', 'cgn-google-reviews' ),
			__( 'Settings', 'cgn-google-reviews' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * @param array $links Plugin row links.
	 * @return array
	 */
	public static function action_link( $links ) {
		$url = admin_url( 'edit.php?post_type=' . Post_Type::NAME . '&page=' . self::PAGE );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'cgn-google-reviews' ) . '</a>' );
		return $links;
	}

	public static function register() {
		register_setting(
			self::PAGE,
			Plugin::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => array(),
			)
		);

		add_settings_section( 'cgn_gr_rules', __( 'Which reviews show', 'cgn-google-reviews' ), array( __CLASS__, 'section_rules' ), self::PAGE );
		add_settings_field( 'min_rating', __( 'Minimum rating', 'cgn-google-reviews' ), array( __CLASS__, 'field_min_rating' ), self::PAGE, 'cgn_gr_rules', array( 'label_for' => 'cgn-gr-min-rating' ) );
		add_settings_field( 'require_text', __( 'Review text', 'cgn-google-reviews' ), array( __CLASS__, 'field_require_text' ), self::PAGE, 'cgn_gr_rules', array( 'label_for' => 'cgn-gr-require-text' ) );
		add_settings_field( 'max_published', __( 'How many to show', 'cgn-google-reviews' ), array( __CLASS__, 'field_max' ), self::PAGE, 'cgn_gr_rules', array( 'label_for' => 'cgn-gr-max' ) );

		add_settings_section( 'cgn_gr_format', __( 'How reviews read', 'cgn-google-reviews' ), '__return_false', self::PAGE );
		add_settings_field( 'name_format', __( 'Reviewer name', 'cgn-google-reviews' ), array( __CLASS__, 'field_name_format' ), self::PAGE, 'cgn_gr_format', array( 'label_for' => 'cgn-gr-name-format' ) );
		add_settings_field( 'date_format', __( 'Date format', 'cgn-google-reviews' ), array( __CLASS__, 'field_date_format' ), self::PAGE, 'cgn_gr_format', array( 'label_for' => 'cgn-gr-date-format' ) );
	}

	/**
	 * @param mixed $input Raw submitted values.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		// Only known settings are kept, so retired ones (0.1.0's reply label) drop out on the next save.
		$out   = array_intersect_key( Plugin::get_settings(), Plugin::defaults() );

		$out['min_rating']    = isset( $input['min_rating'] ) ? max( 1, min( 5, (int) $input['min_rating'] ) ) : $out['min_rating'];
		$out['require_text']  = empty( $input['require_text'] ) ? 0 : 1;
		$out['max_published'] = isset( $input['max_published'] ) ? max( 0, (int) $input['max_published'] ) : $out['max_published'];

		if ( isset( $input['name_format'] ) && in_array( $input['name_format'], array( 'first_initial', 'first', 'full' ), true ) ) {
			$out['name_format'] = $input['name_format'];
		}
		if ( isset( $input['date_format'] ) && '' !== trim( (string) $input['date_format'] ) ) {
			$out['date_format'] = sanitize_text_field( $input['date_format'] );
		}

		return $out;
	}

	/** Re-applies the rules as soon as the settings change, so the site updates without waiting for a sync. */
	public static function settings_changed() {
		Repository::apply_rules();
	}

	public static function section_rules() {
		echo '<p>' . esc_html__( 'Reviews that pass these rules are published, newest first. The rest stay in the list as drafts, so loosening a rule brings them back.', 'cgn-google-reviews' ) . '</p>';
	}

	public static function field_min_rating() {
		$value   = (int) Plugin::setting( 'min_rating' );
		$options = array(
			5 => __( '5 stars only', 'cgn-google-reviews' ),
			4 => __( '4 stars and up', 'cgn-google-reviews' ),
			3 => __( '3 stars and up', 'cgn-google-reviews' ),
			2 => __( '2 stars and up', 'cgn-google-reviews' ),
			1 => __( 'Any rating', 'cgn-google-reviews' ),
		);
		echo '<select id="cgn-gr-min-rating" name="' . esc_attr( Plugin::OPTION ) . '[min_rating]">';
		foreach ( $options as $stars => $label ) {
			echo '<option value="' . esc_attr( (string) $stars ) . '"' . selected( $value, $stars, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}

	public static function field_require_text() {
		echo '<label><input type="checkbox" id="cgn-gr-require-text" name="' . esc_attr( Plugin::OPTION ) . '[require_text]" value="1"' . checked( (int) Plugin::setting( 'require_text' ), 1, false ) . '> ';
		esc_html_e( 'Only show reviews that have written text (skip star-only ratings)', 'cgn-google-reviews' );
		echo '</label>';
	}

	public static function field_max() {
		echo '<input type="number" min="0" step="1" class="small-text" id="cgn-gr-max" name="' . esc_attr( Plugin::OPTION ) . '[max_published]" value="' . esc_attr( (string) (int) Plugin::setting( 'max_published' ) ) . '"> ';
		echo '<span class="description">' . esc_html__( '0 shows every review that qualifies.', 'cgn-google-reviews' ) . '</span>';
	}

	public static function field_name_format() {
		$value   = (string) Plugin::setting( 'name_format' );
		$options = array(
			'first_initial' => __( 'First name and last initial (Sarah M.)', 'cgn-google-reviews' ),
			'first'         => __( 'First name only (Sarah)', 'cgn-google-reviews' ),
			'full'          => __( 'Full name as shown on Google (Sarah Miller)', 'cgn-google-reviews' ),
		);
		echo '<select id="cgn-gr-name-format" name="' . esc_attr( Plugin::OPTION ) . '[name_format]">';
		foreach ( $options as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $value, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select>';
	}

	public static function field_date_format() {
		$value = (string) Plugin::setting( 'date_format' );
		echo '<input type="text" class="regular-text" id="cgn-gr-date-format" name="' . esc_attr( Plugin::OPTION ) . '[date_format]" value="' . esc_attr( $value ) . '"> ';
		/* translators: %s: today's date in the chosen format. */
		echo '<span class="description">' . esc_html( sprintf( __( 'PHP date format. Today reads as: %s', 'cgn-google-reviews' ), wp_date( $value ) ) ) . '</span>';
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$status = get_option( Plugin::STATUS_OPTION, array() );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Review Settings', 'cgn-google-reviews' ); ?></h1>

			<div class="card">
				<h2><?php esc_html_e( 'Last sync', 'cgn-google-reviews' ); ?></h2>
				<?php if ( empty( $status['time'] ) ) : ?>
					<p><?php esc_html_e( 'No reviews have arrived yet. CGN\'s scheduled job sends them to this site; once it runs, they appear under Reviews.', 'cgn-google-reviews' ); ?></p>
				<?php else : ?>
					<p>
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: date and time, 2: reviews received, 3: shown, 4: hidden. */
								__( '%1$s: %2$d reviews received, %3$d shown on the site, %4$d hidden by the rules below.', 'cgn-google-reviews' ),
								wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $status['time'] ),
								(int) $status['received'],
								(int) $status['published'],
								(int) $status['hidden']
							)
						);
						?>
					</p>
				<?php endif; ?>
			</div>

			<form method="post" action="options.php">
				<?php
				settings_fields( self::PAGE );
				do_settings_sections( self::PAGE );
				submit_button();
				?>
			</form>

			<h2><?php esc_html_e( 'Showing reviews in Elementor', 'cgn-google-reviews' ); ?></h2>
			<p><?php esc_html_e( 'Build a Loop with the "Reviews" post type, ordered by date, newest first. Inside the loop item, bind each text to a dynamic tag:', 'cgn-google-reviews' ); ?></p>
			<ul class="ul-disc">
				<li><?php esc_html_e( 'Review text: Post Content (or Post Excerpt)', 'cgn-google-reviews' ); ?></li>
				<li><?php esc_html_e( 'Post Custom Field with key reviewer_name, reviewer_initial, review_stars, review_rating, review_date or review_source', 'cgn-google-reviews' ); ?></li>
				<li><?php esc_html_e( 'Or the shortcode [cgn_review field="name"] (name, initial, stars, rating, date, text or source).', 'cgn-google-reviews' ); ?></li>
			</ul>
		</div>
		<?php
	}
}
