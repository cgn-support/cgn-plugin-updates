<?php
/**
 * Stores synced reviews and applies the display rules.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Repository {

	/** Google's starRating values. */
	const STAR_WORDS = array(
		'ONE'   => 1,
		'TWO'   => 2,
		'THREE' => 3,
		'FOUR'  => 4,
		'FIVE'  => 5,
	);

	/**
	 * A replace sync that would remove more than this share of the site's reviews is refused
	 * unless it's forced, because it usually means the fetch came back incomplete (for example
	 * a failed page partway through Google's pagination), not that Google deleted them.
	 */
	const MAX_REMOVE_SHARE = 0.2;

	/** A replace sync may always remove this many reviews, so small review sets aren't blocked. */
	const MAX_REMOVE_FREE = 2;

	/** True while a sync runs, so the trash hooks know the sync made the change, not a person. */
	private static $syncing = false;

	/**
	 * Saves a full set of reviews from one source, then re-applies the display rules.
	 *
	 * @param string $source  Source key, e.g. "google".
	 * @param array  $reviews Raw review objects (Google Business Profile shape or the simple shape, see normalize()).
	 * @param bool   $replace When true, reviews from this source that aren't in $reviews are moved to the Trash
	 *                        (they were deleted on Google). Send the full list every time when using it.
	 * @param bool   $force   Skip the check that refuses a replace sync removing too many reviews at once.
	 * @return array|\WP_Error Counts (received, skipped, created, updated, restored, removed, published, hidden),
	 *                         or an error when the sync was refused. A refused sync changes nothing.
	 */
	public static function sync( $source, array $reviews, $replace, $force = false ) {
		$counts     = array(
			'received' => count( $reviews ),
			'skipped'  => 0,
			'created'  => 0,
			'updated'  => 0,
			'restored' => 0,
			'removed'  => 0,
		);
		$normalized = array();

		foreach ( $reviews as $raw ) {
			$review = is_array( $raw ) ? self::normalize( $raw ) : null;
			if ( null === $review ) {
				++$counts['skipped'];
				continue;
			}
			$normalized[ $review['id'] ] = $review;
		}

		// Work out what a replace would remove before writing anything, so a refused sync changes nothing.
		$to_remove = array();
		if ( $replace ) {
			$live = self::posts_for_source( $source ); // Never includes the Trash.
			foreach ( $live as $post_id => $source_id ) {
				if ( ! isset( $normalized[ $source_id ] ) ) {
					$to_remove[] = $post_id;
				}
			}
			$allowed = max( self::MAX_REMOVE_FREE, (int) floor( count( $live ) * self::MAX_REMOVE_SHARE ) );
			if ( ! $force && count( $to_remove ) > $allowed ) {
				return new \WP_Error(
					'cgn_gr_too_many_removed',
					sprintf(
						/* translators: 1: reviews the sync would remove, 2: reviews on the site, 3: reviews received. */
						__( 'Refused: this sync would remove %1$d of the %2$d reviews on the site (it sent %3$d). That usually means the fetch from Google was incomplete. Nothing was changed. If Google really removed them, send the sync again with "force": true.', 'cgn-google-reviews' ),
						count( $to_remove ),
						count( $live ),
						$counts['received']
					),
					array(
						'status'       => 409,
						'would_remove' => count( $to_remove ),
						'on_site'      => count( $live ),
						'received'     => $counts['received'],
					)
				);
			}
		}

		self::$syncing = true;

		foreach ( $normalized as $review ) {
			$result = self::upsert( $source, $review );
			if ( $result ) {
				++$counts[ $result ];
			}
		}

		foreach ( $to_remove as $post_id ) {
			// Marked as removed by the sync, so it comes back if Google lists it again.
			update_post_meta( $post_id, Post_Type::META_TRASHED_BY, 'sync' );
			wp_trash_post( $post_id );
			++$counts['removed'];
		}

		self::$syncing = false;

		return array_merge( $counts, self::apply_rules() );
	}

	/**
	 * A person moved a review to the Trash or restored it. Clears the sync's mark (a review a
	 * person trashed stays trashed) and re-applies the rules, so a review limit fills back up.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function trash_changed( $post_id ) {
		if ( self::$syncing || Post_Type::NAME !== get_post_type( $post_id ) ) {
			return;
		}
		delete_post_meta( $post_id, Post_Type::META_TRASHED_BY );
		// Once per request, so trashing many reviews in bulk applies the rules a single time.
		if ( ! has_action( 'shutdown', array( __CLASS__, 'apply_rules' ) ) ) {
			add_action( 'shutdown', array( __CLASS__, 'apply_rules' ) );
		}
	}

	/**
	 * Accepts a review from the Google Business Profile API as-is, or a simple shape:
	 *   { id, author, rating (1-5), text, created (ISO 8601), updated }
	 * Owner replies (reviewReply) are ignored: reviews show without them.
	 *
	 * @param array $r Raw review.
	 * @return array|null Normalized review, or null when it has no ID.
	 */
	public static function normalize( array $r ) {
		$id = self::first( $r, array( 'reviewId', 'id', 'review_id' ) );
		if ( '' === $id ) {
			return null;
		}

		$author = isset( $r['reviewer']['displayName'] ) ? (string) $r['reviewer']['displayName'] : self::first( $r, array( 'author', 'reviewer_name' ) );

		$rating = 0;
		if ( isset( $r['starRating'] ) && isset( self::STAR_WORDS[ strtoupper( (string) $r['starRating'] ) ] ) ) {
			$rating = self::STAR_WORDS[ strtoupper( (string) $r['starRating'] ) ];
		} elseif ( isset( $r['rating'] ) ) {
			$rating = (int) $r['rating'];
		}

		$created = strtotime( self::first( $r, array( 'createTime', 'created', 'review_date' ) ) );
		$updated = strtotime( self::first( $r, array( 'updateTime', 'updated' ) ) );

		return array(
			'id'         => substr( sanitize_text_field( $id ), 0, 191 ),
			'author'     => sanitize_text_field( $author ),
			'rating'     => max( 0, min( 5, $rating ) ),
			'text'       => self::clean_text( self::first( $r, array( 'comment', 'text', 'review_text' ) ) ),
			'created'    => $created ? $created : time(),
			'updated'    => $updated ? $updated : ( $created ? $created : time() ),
		);
	}

	/**
	 * Google appends machine translations to the review text. Keep the reviewer's own words.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	public static function clean_text( $text ) {
		$text = (string) $text;
		if ( preg_match( '/\(Original\)\s*(.+)$/su', $text, $m ) ) {
			$text = $m[1];
		}
		$text = preg_replace( '/^\(Translated by Google\)\s*/u', '', $text );
		return trim( sanitize_textarea_field( $text ) );
	}

	/**
	 * @param string $source Source key.
	 * @param array  $review Normalized review.
	 * @return string|null "created", "updated", "restored", or null when nothing changed.
	 */
	private static function upsert( $source, array $review ) {
		$existing = self::find( $source, $review['id'] );
		$gmt      = gmdate( 'Y-m-d H:i:s', $review['created'] );
		$restored = false;

		// A review an earlier sync removed is listed on Google again (it was missing from an
		// incomplete fetch, or Google restored it): bring it back. One a person trashed stays put.
		if ( $existing && 'trash' === get_post_status( $existing )
			&& 'sync' === get_post_meta( $existing, Post_Type::META_TRASHED_BY, true ) ) {
			wp_untrash_post( $existing ); // Restores as a draft; apply_rules() publishes it if it qualifies.
			delete_post_meta( $existing, Post_Type::META_TRASHED_BY );
			$restored = true;
		}

		$postarr = array(
			'post_type'     => Post_Type::NAME,
			'post_title'    => self::format_name( $review['author'], Plugin::setting( 'name_format' ) ),
			'post_content'  => $review['text'],
			'post_date_gmt' => $gmt,
			'post_date'     => get_date_from_gmt( $gmt ),
		);

		if ( $existing ) {
			if ( (int) get_post_meta( $existing, Post_Type::META_UPDATED, true ) === $review['updated']
				&& ! metadata_exists( 'post', $existing, 'owner_reply' ) ) {
				return $restored ? 'restored' : null;
			}
			$postarr['ID'] = $existing;
			wp_update_post( wp_slash( $postarr ) );
			$post_id = $existing;
			$result  = $restored ? 'restored' : 'updated';
		} else {
			$postarr['post_status'] = 'draft'; // apply_rules() publishes it if it qualifies.
			$post_id                = wp_insert_post( wp_slash( $postarr ) );
			if ( ! $post_id || is_wp_error( $post_id ) ) {
				return null;
			}
			$result = 'created';
		}

		update_post_meta( $post_id, Post_Type::META_SOURCE, $source );
		update_post_meta( $post_id, Post_Type::META_SOURCE_ID, $review['id'] );
		update_post_meta( $post_id, Post_Type::META_AUTHOR, $review['author'] );
		update_post_meta( $post_id, Post_Type::META_UPDATED, $review['updated'] );
		update_post_meta( $post_id, 'review_rating', $review['rating'] );
		update_post_meta( $post_id, 'review_stars', str_repeat( '★', $review['rating'] ) );
		update_post_meta( $post_id, 'review_source', 'google' === $source ? 'Google' : ucfirst( $source ) );

		// 0.1.0 stored owner replies; they're no longer used.
		delete_post_meta( $post_id, 'owner_reply' );
		delete_post_meta( $post_id, '_cgn_gr_reply_time' );

		return $result;
	}

	/**
	 * Publishes the reviews that pass the rules on the settings screen, newest first up to
	 * the limit, and drafts the rest. Also refreshes the name and date fields, so changing
	 * a format on the settings screen updates every review.
	 *
	 * @return array Counts: published, hidden.
	 */
	public static function apply_rules() {
		$settings = Plugin::get_settings();
		$min      = max( 1, min( 5, (int) $settings['min_rating'] ) );
		$limit    = max( 0, (int) $settings['max_published'] );

		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => array( 'publish', 'draft' ),
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		$published = 0;
		$hidden    = 0;

		foreach ( $ids as $post_id ) {
			$rating = (int) get_post_meta( $post_id, 'review_rating', true );
			$text   = trim( (string) get_post_field( 'post_content', $post_id ) );

			$reason = '';
			if ( $rating < $min ) {
				$reason = 'rating';
			} elseif ( ! empty( $settings['require_text'] ) && '' === $text ) {
				$reason = 'no_text';
			} elseif ( $limit && $published >= $limit ) {
				$reason = 'limit';
			}

			$name   = self::format_name( (string) get_post_meta( $post_id, Post_Type::META_AUTHOR, true ), $settings['name_format'] );
			$status = '' === $reason ? 'publish' : 'draft';

			$update = array();
			if ( get_post_status( $post_id ) !== $status ) {
				$update['post_status'] = $status;
			}
			if ( get_the_title( $post_id ) !== $name ) {
				$update['post_title'] = $name;
			}
			if ( $update ) {
				$update['ID'] = $post_id;
				wp_update_post( wp_slash( $update ) );
			}

			update_post_meta( $post_id, 'reviewer_name', $name );
			update_post_meta( $post_id, 'reviewer_initial', self::initial( $name ) );
			update_post_meta( $post_id, 'review_date', get_the_date( $settings['date_format'], $post_id ) );
			update_post_meta( $post_id, Post_Type::META_HIDDEN, $reason );

			if ( '' === $reason ) {
				++$published;
			} else {
				++$hidden;
			}
		}

		return array(
			'published' => $published,
			'hidden'    => $hidden,
		);
	}

	/**
	 * @param string $name   Reviewer's display name from Google.
	 * @param string $format first_initial ("Sarah M."), first ("Sarah") or full ("Sarah Miller").
	 * @return string
	 */
	public static function format_name( $name, $format ) {
		$parts = preg_split( '/\s+/u', trim( (string) $name ), -1, PREG_SPLIT_NO_EMPTY );
		if ( ! $parts ) {
			return __( 'Google reviewer', 'cgn-google-reviews' );
		}
		if ( 'full' === $format ) {
			return implode( ' ', $parts );
		}
		$first = self::upper_first( $parts[0] );
		if ( 'first' === $format || count( $parts ) < 2 ) {
			return $first;
		}
		$last = end( $parts );
		return $first . ' ' . self::upper_first( self::substr( $last, 0, 1 ) ) . '.';
	}

	/**
	 * @param string $name Formatted name.
	 * @return string
	 */
	public static function initial( $name ) {
		return self::upper_first( self::substr( trim( (string) $name ), 0, 1 ) );
	}

	/** @return array<int,string> Post ID => source review ID, every status including Trash. */
	private static function posts_for_source( $source ) {
		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => Post_Type::META_SOURCE, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => $source, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		$out = array();
		foreach ( $ids as $post_id ) {
			$out[ $post_id ] = (string) get_post_meta( $post_id, Post_Type::META_SOURCE_ID, true );
		}
		return $out;
	}

	/**
	 * Finds a review by its source ID in any status, including Trash, so a review someone
	 * trashed by hand stays trashed when it syncs again.
	 *
	 * @return int Post ID, or 0.
	 */
	private static function find( $source, $source_id ) {
		$ids = get_posts(
			array(
				'post_type'      => Post_Type::NAME,
				'post_status'    => array( 'publish', 'draft', 'trash' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array(
						'key'   => Post_Type::META_SOURCE_ID,
						'value' => $source_id,
					),
					array(
						'key'   => Post_Type::META_SOURCE,
						'value' => $source,
					),
				),
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * @param array $r    Raw review.
	 * @param array $keys Keys to try, in order.
	 * @return string First non-empty value.
	 */
	private static function first( array $r, array $keys ) {
		foreach ( $keys as $key ) {
			if ( isset( $r[ $key ] ) && is_scalar( $r[ $key ] ) && '' !== (string) $r[ $key ] ) {
				return (string) $r[ $key ];
			}
		}
		return '';
	}

	private static function substr( $text, $start, $length ) {
		return function_exists( 'mb_substr' ) ? mb_substr( $text, $start, $length ) : substr( $text, $start, $length );
	}

	private static function upper_first( $text ) {
		if ( ! function_exists( 'mb_strtoupper' ) ) {
			return ucfirst( $text );
		}
		return mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 );
	}
}
