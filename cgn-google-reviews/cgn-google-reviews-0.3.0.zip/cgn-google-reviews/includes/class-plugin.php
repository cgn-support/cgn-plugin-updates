<?php
/**
 * Plugin bootstrap and settings access.
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** Option name holding all plugin settings. */
	const OPTION = 'cgn_gr_settings';

	/** Option name holding the result of the most recent sync. */
	const STATUS_OPTION = 'cgn_gr_sync_status';

	/** Option name holding the most recent refused sync (would have removed too many reviews). */
	const REFUSED_OPTION = 'cgn_gr_sync_refused';

	/**
	 * With no successful sync for this long, the site warns that reviews may be out of date.
	 * The sync runs weekly, so 8 days allows one late run; it matches the job's own STALE_DAYS.
	 * Filter: cgn_gr_stale_after.
	 */
	const STALE_AFTER = 8 * \DAY_IN_SECONDS;

	/** @var Plugin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		Post_Type::init();
		Settings::init();
		Rest::init();
		Shortcode::init();
	}

	/** Registers the post type before flushing so its admin screens work straight away. */
	public static function activate() {
		Post_Type::register();
		flush_rewrite_rules();
	}

	/**
	 * Defaults match the CGN standard: 5-star reviews that have text, newest first,
	 * every qualifying review shown, names as "First L.".
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'min_rating'    => 5,
			'require_text'  => 1,
			'max_published' => 0, // 0 = show every review that qualifies.
			'name_format'   => 'first_initial',
			'date_format'   => 'M j, Y',
		);
	}

	/** @return array */
	public static function get_settings() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * @param string $key Setting name.
	 * @return mixed
	 */
	public static function setting( $key ) {
		$settings = self::get_settings();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}

	/**
	 * Whether the reviews on the site are being kept up to date.
	 *
	 * @return array {
	 *     @type string     $state       "never" (no sync yet), "ok", or "stale" (no successful sync within stale_after).
	 *     @type int        $last_sync   Time of the last successful sync, or 0.
	 *     @type int        $stale_after Seconds without a sync before the reviews count as stale.
	 *     @type array|null $refused     The last refused sync, when it's newer than the last successful one.
	 * }
	 */
	public static function sync_health() {
		$status      = get_option( self::STATUS_OPTION, array() );
		$last        = is_array( $status ) && ! empty( $status['time'] ) ? (int) $status['time'] : 0;
		$stale_after = max( HOUR_IN_SECONDS, (int) apply_filters( 'cgn_gr_stale_after', self::STALE_AFTER ) );
		$refused     = get_option( self::REFUSED_OPTION, null );
		if ( ! is_array( $refused ) || empty( $refused['time'] ) || (int) $refused['time'] <= $last ) {
			$refused = null;
		}

		if ( ! $last ) {
			$state = 'never';
		} elseif ( time() - $last > $stale_after ) {
			$state = 'stale';
		} else {
			$state = 'ok';
		}

		return array(
			'state'       => $state,
			'last_sync'   => $last,
			'stale_after' => $stale_after,
			'refused'     => $refused,
		);
	}
}
