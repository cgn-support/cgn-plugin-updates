<?php
/**
 * The Review post type, its display fields, and its admin list.
 *
 * Each synced review is one post: the title is the formatted reviewer name, the
 * content is the review text, and the post date is when the review was written,
 * so "newest first" is WordPress's normal date order. Reviews that pass the rules
 * on the settings screen are published; the rest are kept as drafts.
 *
 * Display fields (use them with Elementor's Post Custom Field dynamic tag):
 *   reviewer_name     formatted name, same as the title ("Sarah M.")
 *   reviewer_initial  first letter of the name, for an avatar circle
 *   review_rating     1 to 5
 *   review_stars      the rating as stars ("★★★★★")
 *   review_date       the review date in the format chosen on the settings screen
 *   review_source     "Google"
 *
 * @package CGN_GR
 */

namespace CGN_GR;

defined( 'ABSPATH' ) || exit;

final class Post_Type {

	const NAME = 'cgn_review';

	/** Display fields, exposed to Elementor and the REST API. */
	const DISPLAY_META = array(
		'reviewer_name'    => 'string',
		'reviewer_initial' => 'string',
		'review_rating'    => 'integer',
		'review_stars'     => 'string',
		'review_date'      => 'string',
		'review_source'    => 'string',
	);

	/** Internal fields: where the review came from and the raw data the display fields are built from. */
	const META_SOURCE      = '_cgn_gr_source';
	const META_SOURCE_ID   = '_cgn_gr_source_id';
	const META_AUTHOR      = '_cgn_gr_author';
	const META_UPDATED     = '_cgn_gr_updated';
	const META_HIDDEN      = '_cgn_gr_hidden';
	/** "sync" when the sync moved the review to the Trash (Google stopped listing it), so it can come back. */
	const META_TRASHED_BY  = '_cgn_gr_trashed_by';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'manage_' . self::NAME . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::NAME . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
		add_filter( 'bulk_actions-edit-' . self::NAME, array( __CLASS__, 'bulk_actions' ) );
		add_action( 'load-post.php', array( __CLASS__, 'block_edit_screen' ) );
		add_action( 'admin_notices', array( __CLASS__, 'list_notice' ) );
		add_action( 'trashed_post', array( 'CGN_GR\\Repository', 'trash_changed' ) );
		add_action( 'untrashed_post', array( 'CGN_GR\\Repository', 'trash_changed' ) );
	}

	public static function register() {
		register_post_type(
			self::NAME,
			array(
				'labels'              => array(
					'name'               => __( 'Reviews', 'cgn-google-reviews' ),
					'singular_name'      => __( 'Review', 'cgn-google-reviews' ),
					'all_items'          => __( 'All Reviews', 'cgn-google-reviews' ),
					'edit_item'          => __( 'Edit Review', 'cgn-google-reviews' ),
					'search_items'       => __( 'Search Reviews', 'cgn-google-reviews' ),
					'not_found'          => __( 'No reviews yet. They appear after the first sync.', 'cgn-google-reviews' ),
					'not_found_in_trash' => __( 'No reviews in the trash.', 'cgn-google-reviews' ),
				),
				'description'         => __( 'Google reviews synced by CGN.', 'cgn-google-reviews' ),
				// Public so Elementor's loop query lists it (Elementor only offers public post types that
				// show in nav menus). Not publicly queryable, so reviews never get pages of their own.
				'public'              => true,
				'show_in_nav_menus'   => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'menu_position'       => 25,
				'menu_icon'           => 'dashicons-star-filled',
				'supports'            => array( 'title', 'editor', 'custom-fields' ),
				'map_meta_cap'        => true,
				'capabilities'        => array(
					// Reviews come from the sync, so there's no "Add New".
					'create_posts' => 'do_not_allow',
				),
			)
		);

		foreach ( self::DISPLAY_META as $key => $type ) {
			register_post_meta(
				self::NAME,
				$key,
				array(
					'type'          => $type,
					'single'        => true,
					'show_in_rest'  => true,
					'auth_callback' => array( __CLASS__, 'can_edit_meta' ),
				)
			);
		}
	}

	public static function can_edit_meta() {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * @param array $columns Default list columns.
	 * @return array
	 */
	public static function columns( $columns ) {
		$out = array();
		foreach ( $columns as $key => $label ) {
			if ( 'title' === $key ) {
				$out['title']       = __( 'Reviewer', 'cgn-google-reviews' );
				$out['cgn_rating']  = __( 'Rating', 'cgn-google-reviews' );
				$out['cgn_excerpt'] = __( 'Review', 'cgn-google-reviews' );
				$out['cgn_shown']   = __( 'On the site', 'cgn-google-reviews' );
				continue;
			}
			$out[ $key ] = $label;
		}
		return $out;
	}

	/**
	 * @param string $column  Column key.
	 * @param int    $post_id Review post ID.
	 */
	public static function column( $column, $post_id ) {
		switch ( $column ) {
			case 'cgn_rating':
				echo esc_html( (string) get_post_meta( $post_id, 'review_stars', true ) );
				break;

			case 'cgn_excerpt':
				$text = wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) );
				echo '' === $text ? '<em>' . esc_html__( 'No text', 'cgn-google-reviews' ) . '</em>' : esc_html( wp_trim_words( $text, 18 ) );
				break;

			case 'cgn_shown':
				if ( 'publish' === get_post_status( $post_id ) ) {
					esc_html_e( 'Shown', 'cgn-google-reviews' );
					break;
				}
				if ( 'trash' === get_post_status( $post_id ) ) {
					echo esc_html(
						'sync' === get_post_meta( $post_id, self::META_TRASHED_BY, true )
							? __( 'No longer on Google (comes back if Google lists it again)', 'cgn-google-reviews' )
							: __( 'Trashed by hand (stays off the site)', 'cgn-google-reviews' )
					);
					break;
				}
				$reasons = array(
					'rating'  => __( 'Hidden: below the minimum rating', 'cgn-google-reviews' ),
					'no_text' => __( 'Hidden: no review text', 'cgn-google-reviews' ),
					'limit'   => __( 'Hidden: past the review limit', 'cgn-google-reviews' ),
				);
				$reason  = (string) get_post_meta( $post_id, self::META_HIDDEN, true );
				echo esc_html( isset( $reasons[ $reason ] ) ? $reasons[ $reason ] : __( 'Hidden', 'cgn-google-reviews' ) );
				break;
		}
	}

	/**
	 * Reviews are a copy of what's on Google, so the list only offers Trash (which keeps a
	 * review off the site until it's restored). There's nothing to edit here.
	 *
	 * @param array    $actions Row actions.
	 * @param \WP_Post $post    Row post.
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( self::NAME !== $post->post_type ) {
			return $actions;
		}
		unset( $actions['edit'], $actions['inline hide-if-no-js'] );
		return $actions;
	}

	/**
	 * @param array $actions Bulk actions.
	 * @return array
	 */
	public static function bulk_actions( $actions ) {
		unset( $actions['edit'] );
		return $actions;
	}

	/**
	 * Sends the edit screen back to the list: edits would be replaced by the next sync anyway.
	 * Only the edit screen: post.php also handles the Trash, Restore and Delete links.
	 */
	public static function block_edit_screen() {
		$action  = isset( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'edit' !== $action || ! $post_id || self::NAME !== get_post_type( $post_id ) ) {
			return;
		}
		wp_safe_redirect( admin_url( 'edit.php?post_type=' . self::NAME . '&cgn_gr_read_only=1' ) );
		exit;
	}

	/** The banner at the top of the Reviews list: where reviews come from, and the sync's health. */
	public static function list_notice() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'edit-' . self::NAME !== $screen->id ) {
			return;
		}

		$health = Plugin::sync_health();
		$text   = __( 'These reviews are a copy of the Google Business Profile, kept up to date by CGN\'s sync. Change reviews on Google, not here. To keep a review off the site, move it to the Trash.', 'cgn-google-reviews' );
		if ( 'never' !== $health['state'] ) {
			/* translators: %s: how long ago, e.g. "3 hours". */
			$text .= ' ' . sprintf( __( 'Last synced %s ago.', 'cgn-google-reviews' ), human_time_diff( $health['last_sync'] ) );
		}
		$class = isset( $_GET['cgn_gr_read_only'] ) ? 'notice-warning' : 'notice-info'; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice ' . esc_attr( $class ) . '"><p>' . esc_html( $text ) . '</p></div>';
	}
}
