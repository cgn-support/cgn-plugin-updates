## 0.3.0
- An incomplete fetch from Google can no longer wipe reviews: a sync that would remove more than 20% of the site's reviews is refused and changes nothing, unless the job sends "force": true.
- Reviews a sync removed come back on their own when Google lists them again. Reviews someone trashed by hand still stay trashed, and the list shows which is which. (Reviews a 0.2.0 sync removed can't be told apart from hand-trashed ones, so they stay in the Trash. Restore them by hand if needed.)
- Administrators see a warning on the Dashboard and Reviews screens when reviews haven't synced in 8 days (the sync runs weekly) or a sync was refused. The status endpoint reports "health" (ok, stale or never) for monitoring.
- Reviews are read-only in WordPress: no Edit screen or Quick Edit, just Trash, plus a note that they're a copy of the Google Business Profile.
- Trashing or restoring a review by hand re-applies the rules straight away, so a review limit fills back up without waiting for the next sync.

## 0.2.0
- Owner replies are no longer stored or shown. The reply field, the reply shortcode and the reply label setting are gone, and replies saved by 0.1.0 are cleared at the next sync.

## 0.1.0
- Reviews post type that holds the site's Google reviews, synced by CGN's scheduled job through a secure REST endpoint.
- Rules on Reviews → Settings: minimum rating, text required, how many to show, newest first. Reviews that don't qualify stay as drafts.
- Reviewer names as "First L." by default, review dates in a chosen format, and the owner's reply with a label.
- Every field works with Elementor's Post Custom Field dynamic tag, plus a [cgn_review] shortcode for the reply.
