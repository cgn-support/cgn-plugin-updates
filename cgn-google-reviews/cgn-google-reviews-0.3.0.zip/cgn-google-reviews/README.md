# CGN Google Reviews

Shows a client's Google reviews on their site in any layout with an Elementor loop. The Google Business Profile is the only source of truth: the site keeps a read-only copy of its reviews as WordPress posts, which the sync replaces on every run. The plugin stores, filters and formats that copy. It does not fetch from Google itself: a separate sync job reads the client's Google Business Profile and sends the full list to the site.

Why a copy instead of loading reviews live from Google on each page view: Elementor's Loop Grid and Loop Carousel only work with posts. One Google connection in the job is safer than credentials on every client site. Reviews rendered on the server load fast and can be crawled. And the section keeps working when Google's API is down.

## The sync job

**The sync job lives on the CGN Mac mini, not in this repo:** `/Users/cgn/Claude/Tools/review-sync/` (`sync.py`, with `sites.json` listing the sites it syncs). It runs from the mini because that's where the Google service account (cgnanalytics@, the same login the `gbp` CLI uses) is set up, and only the `cgn` account can read its key. The job's own README there covers usage, adding a site, and the SiteGround bot-protection block.

- **Schedule:** launchd job `com.cgn.review-sync`, every Monday at 06:40 (Mac mini time). Weekly is on purpose, so the site only warns after 8 days with no sync (`cgn_gr_stale_after` filter), matching the job's own `STALE_DAYS`.
- **Reporting:** every run posts to #claude-cgn and names any site with no good sync in 8 days.
- **Safety on the job's side:** a Google error aborts that site before anything is posted, an empty list is never sent, and it refuses a replace that removes more than 20% of what it last posted unless run with `--force`. The plugin repeats that 20% check against what's on the site (below), so a forced run has to send `"force": true` too.
- **Adding a client:** install the plugin, then add the site to `sites.json` on the mini (steps in the job's README).

## Setting up a site

1. Install the plugin from the update feed zip (see the repo README) and activate it.
2. Reviews → Settings: pick the rules. Defaults are 5-star reviews with text, every one that qualifies, newest first, names as "First L.", dates as "Sep 30, 2026". Owner replies aren't stored or shown.
3. Make sure the site has an administrator application password in `clients.json`, and add the site to `sites.json` in the review sync job on the Mac mini (see above).
4. In Elementor, build a Loop on the "Reviews" post type ordered by date, newest first, and bind the card text to dynamic tags (below).

## Fields for Elementor

| What | Dynamic tag |
|---|---|
| Review text | Post Content |
| Reviewer name ("Sarah M.") | Post Title, or Post Custom Field `reviewer_name` |
| Avatar letter | Post Custom Field `reviewer_initial` |
| Stars ("★★★★★") | Post Custom Field `review_stars` |
| Rating (1 to 5) | Post Custom Field `review_rating` |
| Review date | Post Custom Field `review_date`, or Post Date |
| Source ("Google") | Post Custom Field `review_source` |
| Any field as a shortcode | `[cgn_review field="name"]` (name, initial, stars, rating, date, text or source) |

## Sync contract

`POST /wp-json/cgn-google-reviews/v1/sync`, authenticated as an administrator with an application password.

```json
{
  "source": "google",
  "replace": true,
  "reviews": [ /* every review, newest or oldest first, either shape below */ ]
}
```

Each review can be sent exactly as the Google Business Profile API returns it (`reviewId`, `reviewer.displayName`, `starRating`, `comment`, `createTime`, `updateTime`), or in a simple shape: `id`, `author`, `rating` (1 to 5), `text`, `created`, `updated`. Owner replies (`reviewReply`) are ignored.

- Reviews are matched by ID, so re-sending the same list changes nothing.
- With `replace` on (the default), reviews missing from the list were deleted on Google and go to the Trash. Always send the full list.
- If the review shows up on Google again, the next sync restores it from the Trash.
- An empty list is refused unless `allow_empty` is true, so a failed fetch can't wipe the section.
- A list that would remove more than 20% of the site's reviews (always allowing 2) is refused with a 409 and changes nothing, because that's almost always an incomplete fetch. If Google really did remove them, send it again with `"force": true`. The refusal shows as a warning in wp-admin and in `/status`.
- A review someone moves to the Trash by hand stays there after later syncs.
- Machine translations are stripped, keeping the reviewer's own words.

`GET /wp-json/cgn-google-reviews/v1/status` returns `health` (`ok`, `stale` when there's been no sync for 8 days, or `never`), any sync refused since the last successful one, the last sync's counts (`received`, `created`, `updated`, `restored`, `removed`, `published`, `hidden`), how many reviews are shown, hidden and trashed, and the current settings.
