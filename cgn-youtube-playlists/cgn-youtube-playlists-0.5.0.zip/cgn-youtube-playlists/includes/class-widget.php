<?php
/**
 * YouTube Playlists Elementor widget.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || exit;

class Widget extends Widget_Base {

	const LAYOUTS = array( 'grid', 'carousel', 'featured' );

	const PLAY_SVG = '<svg viewBox="0 0 24 24" focusable="false" aria-hidden="true"><path d="M8 5.5v13l10.5-6.5z"></path></svg>';

	public function get_name() {
		return 'cgn_youtube_playlists';
	}

	public function get_title() {
		return esc_html__( 'YouTube Playlists', 'cgn-youtube-playlists' );
	}

	public function get_icon() {
		return 'eicon-youtube';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'youtube', 'video', 'playlist', 'tabs', 'carousel', 'cgn' );
	}

	/** Keeps Elementor's element cache from freezing the output (and skipping the schema). */
	protected function is_dynamic_content(): bool {
		return true;
	}

	public function get_style_depends() {
		return $this->layout_assets(
			array( 'cgn-ytp-base' ),
			array(
				'grid'     => 'cgn-ytp-grid',
				'carousel' => 'cgn-ytp-carousel',
				'featured' => 'cgn-ytp-featured',
			)
		);
	}

	public function get_script_depends() {
		return $this->layout_assets( array( 'cgn-ytp-core' ), array( 'carousel' => 'cgn-ytp-carousel' ) );
	}

	/**
	 * On the live site, only the chosen layout's files load. The editor gets everything,
	 * since the layout can change at any moment there.
	 *
	 * @param string[] $always    Handles every layout needs.
	 * @param string[] $by_layout Layout => handle.
	 * @return string[]
	 */
	private function layout_assets( array $always, array $by_layout ) {
		$is_type = method_exists( $this, 'is_type_instance' ) && $this->is_type_instance();
		$layout  = ( $is_type || Plugin::is_editor() ) ? '' : (string) $this->get_settings( 'layout' );

		if ( ! in_array( $layout, self::LAYOUTS, true ) ) {
			return array_merge( $always, array_values( $by_layout ) );
		}
		return isset( $by_layout[ $layout ] ) ? array_merge( $always, array( $by_layout[ $layout ] ) ) : $always;
	}

	/* =====================================================================
	 * Controls
	 * =================================================================== */

	protected function register_controls() {
		$this->controls_channel();
		$this->controls_layout();
		$this->controls_style();
	}

	private function controls_channel() {
		$this->start_controls_section( 'section_channel', array( 'label' => esc_html__( 'Channel', 'cgn-youtube-playlists' ) ) );

		$this->add_control(
			'channel_id',
			array(
				'label'       => esc_html__( 'Channel ID', 'cgn-youtube-playlists' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'UC…',
				'label_block' => true,
				'description' => esc_html__( 'Find it in YouTube Studio → Settings → Channel → Advanced settings.', 'cgn-youtube-playlists' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section( 'section_playlists', array( 'label' => esc_html__( 'Playlists', 'cgn-youtube-playlists' ) ) );

		$this->add_control(
			'playlists',
			array(
				'type'        => Playlists_Control::TYPE,
				'description' => esc_html__( 'Turn a playlist off to hide its tab. Drag to reorder. New playlists appear automatically.', 'cgn-youtube-playlists' ),
			)
		);

		$this->add_control(
			'per_tab',
			array(
				'label'   => esc_html__( 'Videos per tab', 'cgn-youtube-playlists' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
				'default' => 6,
			)
		);

		$this->end_controls_section();
	}

	private function controls_layout() {
		$this->start_controls_section( 'section_layout', array( 'label' => esc_html__( 'Layout', 'cgn-youtube-playlists' ) ) );

		$this->add_control(
			'layout',
			array(
				'label'       => esc_html__( 'Layout', 'cgn-youtube-playlists' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => true,
				'toggle'      => false,
				'default'     => 'grid',
				'options'     => array(
					'grid'     => array(
						'title' => esc_html__( 'Grid', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-gallery-grid',
					),
					'carousel' => array(
						'title' => esc_html__( 'Carousel', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-slider-push',
					),
					'featured' => array(
						'title' => esc_html__( 'Featured player', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-video-playlist',
					),
				),
			)
		);

		// Grid.
		$this->add_responsive_control(
			'columns',
			array(
				'label'          => esc_html__( 'Columns', 'cgn-youtube-playlists' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'selectors'      => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-cols: {{VALUE}};' ),
				'condition'      => array( 'layout' => 'grid' ),
			)
		);

		$this->add_control(
			'load_more',
			array(
				'label'     => esc_html__( '"Load more" button', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => '',
				'condition' => array( 'layout' => 'grid' ),
			)
		);

		$this->add_control(
			'load_more_text',
			array(
				'label'     => esc_html__( 'Button text', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Load more videos', 'cgn-youtube-playlists' ),
				'condition' => array(
					'layout'    => 'grid',
					'load_more' => 'yes',
				),
			)
		);

		// Carousel.
		$this->add_responsive_control(
			'cards_visible',
			array(
				'label'          => esc_html__( 'Cards visible', 'cgn-youtube-playlists' ),
				'type'           => Controls_Manager::NUMBER,
				'min'            => 1,
				'max'            => 5,
				'step'           => 1,
				'default'        => 3,
				'tablet_default' => 2,
				'mobile_default' => 1,
				'selectors'      => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-cards: {{VALUE}};' ),
				'condition'      => array( 'layout' => 'carousel' ),
			)
		);

		foreach ( array(
			'arrows'   => array( esc_html__( 'Arrows', 'cgn-youtube-playlists' ), 'yes' ),
			'dots'     => array( esc_html__( 'Dots', 'cgn-youtube-playlists' ), 'yes' ),
			'autoplay' => array( esc_html__( 'Autoplay', 'cgn-youtube-playlists' ), '' ),
		) as $key => $control ) {
			$this->add_control(
				$key,
				array(
					'label'     => $control[0],
					'type'      => Controls_Manager::SWITCHER,
					'default'   => $control[1],
					'condition' => array( 'layout' => 'carousel' ),
				)
			);
		}

		$this->add_control(
			'autoplay_speed',
			array(
				'label'     => esc_html__( 'Autoplay speed (seconds)', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 2,
				'max'       => 20,
				'default'   => 5,
				'condition' => array(
					'layout'   => 'carousel',
					'autoplay' => 'yes',
				),
			)
		);

		// Featured player.
		$this->add_control(
			'list_position',
			array(
				'label'     => esc_html__( 'List position', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::CHOOSE,
				'toggle'    => false,
				'default'   => 'right',
				'options'   => array(
					'left'  => array(
						'title' => esc_html__( 'Left', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'condition' => array( 'layout' => 'featured' ),
			)
		);

		$this->add_control(
			'list_items',
			array(
				'label'     => esc_html__( 'List items before scroll', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 2,
				'max'       => 12,
				'default'   => 5,
				'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-list-items: {{VALUE}};' ),
				'condition' => array( 'layout' => 'featured' ),
			)
		);

		// All layouts.
		$this->add_control(
			'show_date',
			array(
				'label'     => esc_html__( 'Show publish date', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'separator' => 'before',
			)
		);

		$this->add_control(
			'show_duration',
			array(
				'label'   => esc_html__( 'Show duration', 'cgn-youtube-playlists' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	private function controls_style() {
		$this->start_controls_section(
			'section_style_colors',
			array(
				'label' => esc_html__( 'Colors', 'cgn-youtube-playlists' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'scheme',
			array(
				'label'       => esc_html__( 'Color scheme', 'cgn-youtube-playlists' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'light',
				'options'     => array(
					'light' => esc_html__( 'For light backgrounds', 'cgn-youtube-playlists' ),
					'dark'  => esc_html__( 'For dark backgrounds', 'cgn-youtube-playlists' ),
				),
				'description' => esc_html__( 'Set the background itself on the section or container.', 'cgn-youtube-playlists' ),
			)
		);

		$this->add_control(
			'accent',
			array(
				'label'     => esc_html__( 'Accent color', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1E5A66',
				'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-accent: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_tabs',
			array(
				'label' => esc_html__( 'Tabs', 'cgn-youtube-playlists' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'tab_style',
			array(
				'label'   => esc_html__( 'Tab style', 'cgn-youtube-playlists' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'underline',
				'options' => array(
					'underline' => esc_html__( 'Underline', 'cgn-youtube-playlists' ),
					'pill'      => esc_html__( 'Pill', 'cgn-youtube-playlists' ),
					'segmented' => esc_html__( 'Segmented', 'cgn-youtube-playlists' ),
				),
			)
		);

		$this->add_control(
			'show_counts',
			array(
				'label'   => esc_html__( 'Show video counts', 'cgn-youtube-playlists' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'tab_typography',
				'selector' => '{{WRAPPER}} .cgn-ytp__tab',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_cards',
			array(
				'label' => esc_html__( 'Videos', 'cgn-youtube-playlists' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'radius',
			array(
				'label'      => esc_html__( 'Thumbnail corner radius', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 14,
				),
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-radius: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'gap',
			array(
				'label'      => esc_html__( 'Spacing between videos', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 64,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 24,
				),
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Video title typography', 'cgn-youtube-playlists' ),
				'selector' => '{{WRAPPER}} .cgn-ytp__title, {{WRAPPER}} .cgn-ytp__now-title, {{WRAPPER}} .cgn-ytp__item-title',
			)
		);

		$this->end_controls_section();

		$this->controls_style_load_more();
	}

	/** Style → Load More Button. Colors and border are CSS variables, so the theme can't override them. */
	private function controls_style_load_more() {
		$this->start_controls_section(
			'section_style_more',
			array(
				'label'     => esc_html__( 'Load More Button', 'cgn-youtube-playlists' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'layout'    => 'grid',
					'load_more' => 'yes',
				),
			)
		);

		$this->add_responsive_control(
			'more_align',
			array(
				'label'     => esc_html__( 'Alignment', 'cgn-youtube-playlists' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'start'   => array(
						'title' => esc_html__( 'Left', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center'  => array(
						'title' => esc_html__( 'Center', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-text-align-center',
					),
					'end'     => array(
						'title' => esc_html__( 'Right', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-text-align-right',
					),
					'stretch' => array(
						'title' => esc_html__( 'Full width', 'cgn-youtube-playlists' ),
						'icon'  => 'eicon-text-align-justify',
					),
				),
				'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-align: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'more_spacing',
			array(
				'label'      => esc_html__( 'Space above', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 120,
					),
				),
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'more_typography',
				'selector' => '{{WRAPPER}} .cgn-ytp .cgn-ytp__more',
			)
		);

		$this->start_controls_tabs( 'more_color_tabs' );

		foreach ( array(
			'normal' => esc_html__( 'Normal', 'cgn-youtube-playlists' ),
			'hover'  => esc_html__( 'Hover', 'cgn-youtube-playlists' ),
		) as $state => $state_label ) {
			$suffix = 'hover' === $state ? '-hover' : '';

			$this->start_controls_tab( 'more_tab_' . $state, array( 'label' => $state_label ) );

			$this->add_control(
				'more_color_' . $state,
				array(
					'label'     => esc_html__( 'Text color', 'cgn-youtube-playlists' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-color' . $suffix . ': {{VALUE}};' ),
				)
			);

			$this->add_control(
				'more_bg_' . $state,
				array(
					'label'     => esc_html__( 'Background color', 'cgn-youtube-playlists' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-bg' . $suffix . ': {{VALUE}};' ),
				)
			);

			$this->add_control(
				'more_border_' . $state,
				array(
					'label'     => esc_html__( 'Border color', 'cgn-youtube-playlists' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-border' . $suffix . ': {{VALUE}};' ),
				)
			);

			$this->end_controls_tab();
		}

		$this->end_controls_tabs();

		$this->add_control(
			'more_border_width',
			array(
				'label'      => esc_html__( 'Border width', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 6,
					),
				),
				'separator'  => 'before',
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp' => '--ytp-more-border-width: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'more_radius',
			array(
				'label'      => esc_html__( 'Border radius', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp .cgn-ytp__more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'more_padding',
			array(
				'label'      => esc_html__( 'Padding', 'cgn-youtube-playlists' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .cgn-ytp .cgn-ytp__more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	 * Render
	 * =================================================================== */

	protected function render() {
		$s         = $this->get_settings_for_display();
		$is_editor = Plugin::is_editor();
		$channel   = trim( (string) ( $s['channel_id'] ?? '' ) );

		if ( '' === $channel ) {
			$this->notice( __( 'Add a YouTube channel ID under Content → Channel to load its playlists.', 'cgn-youtube-playlists' ) );
			return;
		}

		$data = Repository::get_channel( $channel );
		if ( is_wp_error( $data ) ) {
			$this->notice( $data->get_error_message(), true );
			return;
		}

		$playlists = self::visible_playlists( $data['playlists'], $s['playlists'] ?? array() );
		if ( empty( $playlists ) ) {
			$this->notice(
				empty( $data['playlists'] )
					? __( 'This channel has no public playlists with videos yet.', 'cgn-youtube-playlists' )
					: __( 'Every playlist is turned off. Turn at least one on under Content → Playlists.', 'cgn-youtube-playlists' )
			);
			return;
		}

		$layout    = in_array( $s['layout'] ?? '', self::LAYOUTS, true ) ? $s['layout'] : 'grid';
		$per_tab   = max( 1, min( 50, (int) ( ! empty( $s['per_tab'] ) ? $s['per_tab'] : 6 ) ) );
		$load_more = 'grid' === $layout && 'yes' === ( $s['load_more'] ?? '' );
		$tab_style = in_array( $s['tab_style'] ?? '', array( 'underline', 'pill', 'segmented' ), true ) ? $s['tab_style'] : 'underline';
		$autoplay  = 'carousel' === $layout && 'yes' === ( $s['autoplay'] ?? '' );
		$speed     = max( 2, min( 20, (int) ( $s['autoplay_speed'] ?? 5 ) ) );

		foreach ( $playlists as $i => $playlist ) {
			// Only what's visible on load goes into the structured data.
			if ( ! $is_editor ) {
				Schema::add_videos( array_slice( $playlist['videos'], 0, $per_tab ) );
			}
			$playlists[ $i ]['videos'] = array_slice( $playlist['videos'], 0, $load_more ? 50 : $per_tab );
		}

		$uid     = 'cgn-ytp-' . $this->get_id();
		$classes = array(
			'cgn-ytp',
			'cgn-ytp--' . $layout,
			'cgn-ytp--tabs-' . $tab_style,
			'dark' === ( $s['scheme'] ?? '' ) ? 'is-dark' : 'is-light',
		);

		printf(
			'<div class="%s" id="%s" data-autoplay="%d" data-speed="%d">',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $uid ),
			$autoplay ? 1 : 0,
			(int) $speed
		);

		$has_tabs = count( $playlists ) > 1;
		if ( $has_tabs ) {
			$this->render_tabs( $playlists, $s, $uid );
		}

		foreach ( $playlists as $i => $playlist ) {
			if ( $has_tabs ) {
				printf(
					'<div class="cgn-ytp__panel" role="tabpanel" id="%1$s-panel-%2$d" aria-labelledby="%1$s-tab-%2$d"%3$s>',
					esc_attr( $uid ),
					(int) $i,
					0 === $i ? '' : ' hidden'
				);
			} else {
				echo '<div class="cgn-ytp__panel">';
			}

			if ( 'carousel' === $layout ) {
				$this->render_carousel( $playlist, $s );
			} elseif ( 'featured' === $layout ) {
				$this->render_featured( $playlist, $s );
			} else {
				$this->render_grid( $playlist, $s, $per_tab, $load_more );
			}

			echo '</div>';
		}

		echo '</div>';
	}

	private function render_tabs( array $playlists, array $s, $uid ) {
		$counts = 'yes' === ( $s['show_counts'] ?? 'yes' );

		printf( '<div class="cgn-ytp__tabs" role="tablist" aria-label="%s">', esc_attr__( 'Video playlists', 'cgn-youtube-playlists' ) );
		foreach ( $playlists as $i => $playlist ) {
			$active = 0 === $i;
			printf(
				'<button type="button" class="cgn-ytp__tab%1$s" role="tab" id="%2$s-tab-%3$d" aria-controls="%2$s-panel-%3$d" aria-selected="%4$s" tabindex="%5$d">%6$s%7$s</button>',
				$active ? ' is-active' : '',
				esc_attr( $uid ),
				(int) $i,
				$active ? 'true' : 'false',
				$active ? 0 : -1,
				esc_html( $playlist['title'] ),
				$counts ? '<span class="cgn-ytp__count">' . esc_html( number_format_i18n( $playlist['count'] ) ) . '</span>' : ''
			);
		}
		echo '</div>';
	}

	private function render_grid( array $playlist, array $s, $per_tab, $load_more ) {
		echo '<div class="cgn-ytp__grid">';
		foreach ( $playlist['videos'] as $i => $video ) {
			$this->render_card( $video, $s, '(max-width: 767px) 100vw, (max-width: 1024px) 50vw, 33vw', $load_more && $i >= $per_tab );
		}
		echo '</div>';

		if ( $load_more && count( $playlist['videos'] ) > $per_tab ) {
			$label = trim( (string) ( $s['load_more_text'] ?? '' ) );
			printf(
				'<div class="cgn-ytp__more-wrap"><button type="button" class="cgn-ytp__more" data-step="%d">%s</button></div>',
				(int) $per_tab,
				esc_html( '' !== $label ? $label : __( 'Load more videos', 'cgn-youtube-playlists' ) )
			);
		}
	}

	private function render_carousel( array $playlist, array $s ) {
		$arrows = 'yes' === ( $s['arrows'] ?? 'yes' );
		$dots   = 'yes' === ( $s['dots'] ?? 'yes' );

		/* translators: %d: slide number. */
		printf( '<div class="cgn-ytp__carousel" data-dot-label="%s">', esc_attr__( 'Go to slide %d', 'cgn-youtube-playlists' ) );
		printf( '<div class="cgn-ytp__track" role="region" aria-label="%s" tabindex="0">', esc_attr( $playlist['title'] ) );
		foreach ( $playlist['videos'] as $video ) {
			$this->render_card( $video, $s, '(max-width: 767px) 80vw, (max-width: 1024px) 45vw, 30vw' );
		}
		echo '</div>';

		if ( $arrows || $dots ) {
			echo '<div class="cgn-ytp__controls">';
			echo $dots ? '<div class="cgn-ytp__dots"></div>' : '<span></span>';
			if ( $arrows ) {
				printf(
					'<div class="cgn-ytp__arrows"><button type="button" class="cgn-ytp__arrow cgn-ytp__prev" aria-label="%s"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14.7 5.3l1.4 1.4-5.3 5.3 5.3 5.3-1.4 1.4L8 12z"></path></svg></button><button type="button" class="cgn-ytp__arrow cgn-ytp__next" aria-label="%s"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9.3 5.3L7.9 6.7l5.3 5.3-5.3 5.3 1.4 1.4L16 12z"></path></svg></button></div>',
					esc_attr__( 'Previous videos', 'cgn-youtube-playlists' ),
					esc_attr__( 'Next videos', 'cgn-youtube-playlists' )
				);
			}
			echo '</div>';
		}
		echo '</div>';
	}

	private function render_featured( array $playlist, array $s ) {
		$first      = $playlist['videos'][0];
		$list_class = 'left' === ( $s['list_position'] ?? 'right' ) ? ' is-list-left' : '';

		echo '<div class="cgn-ytp__featured' . esc_attr( $list_class ) . '">';

		echo '<div class="cgn-ytp__main"><div class="cgn-ytp__player">';
		$this->render_thumb( $first, $s, '(max-width: 767px) 100vw, 66vw', 'cgn-ytp__thumb--lg' );
		echo '</div><div class="cgn-ytp__now">';
		echo '<h3 class="cgn-ytp__now-title">' . esc_html( $first['title'] ) . '</h3>';
		echo '<p class="cgn-ytp__now-meta">' . esc_html( $this->meta_line( $first, $s ) ) . '</p>';
		echo '<p class="cgn-ytp__now-desc">' . esc_html( self::excerpt( $first['description'] ) ) . '</p>';
		echo '</div></div>';

		echo '<ul class="cgn-ytp__list">';
		foreach ( $playlist['videos'] as $i => $video ) {
			$active   = 0 === $i;
			$duration = 'yes' === ( $s['show_duration'] ?? 'yes' ) ? self::format_duration( $video['duration'] ) : '';

			printf(
				'<li><button type="button" class="cgn-ytp__item%s"%s data-video="%s" data-label="%s" data-title="%s" data-meta="%s" data-desc="%s">',
				$active ? ' is-active' : '',
				$active ? ' aria-current="true"' : '',
				esc_attr( $video['id'] ),
				/* translators: %s: video title. */
				esc_attr( sprintf( __( 'Play video: %s', 'cgn-youtube-playlists' ), $video['title'] ) ),
				esc_attr( $video['title'] ),
				esc_attr( $this->meta_line( $video, $s ) ),
				esc_attr( self::excerpt( $video['description'] ) )
			);
			echo '<span class="cgn-ytp__item-thumb">' . self::thumb_img( $video, '128px' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping.
			if ( '' !== $duration ) {
				echo '<span class="cgn-ytp__duration">' . esc_html( $duration ) . '</span>';
			}
			echo '</span><span class="cgn-ytp__item-text">';
			echo '<span class="cgn-ytp__item-title">' . esc_html( $video['title'] ) . '</span>';
			echo '<span class="cgn-ytp__item-now">' . esc_html__( 'Now playing', 'cgn-youtube-playlists' ) . '</span>';
			if ( 'yes' === ( $s['show_date'] ?? 'yes' ) ) {
				echo '<span class="cgn-ytp__item-meta">' . esc_html( self::format_date( $video['published_at'] ) ) . '</span>';
			}
			echo '</span></button></li>';
		}
		echo '</ul>';

		echo '</div>';
	}

	private function render_card( array $video, array $s, $sizes, $hidden = false ) {
		printf( '<div class="cgn-ytp__card%s"%s>', $hidden ? ' is-more' : '', $hidden ? ' hidden' : '' );
		$this->render_thumb( $video, $s, $sizes );
		echo '<h3 class="cgn-ytp__title">' . esc_html( $video['title'] ) . '</h3>';
		if ( 'yes' === ( $s['show_date'] ?? 'yes' ) ) {
			echo '<p class="cgn-ytp__date">' . esc_html( self::format_date( $video['published_at'] ) ) . '</p>';
		}
		echo '</div>';
	}

	/** The click-to-play thumbnail. The YouTube iframe only loads once it's pressed. */
	private function render_thumb( array $video, array $s, $sizes, $extra_class = '' ) {
		$duration = 'yes' === ( $s['show_duration'] ?? 'yes' ) ? self::format_duration( $video['duration'] ) : '';

		printf(
			'<button type="button" class="cgn-ytp__thumb %s" data-video="%s" aria-label="%s">',
			esc_attr( $extra_class ),
			esc_attr( $video['id'] ),
			/* translators: %s: video title. */
			esc_attr( sprintf( __( 'Play video: %s', 'cgn-youtube-playlists' ), $video['title'] ) )
		);
		echo self::thumb_img( $video, $sizes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping.
		echo '<span class="cgn-ytp__play">' . self::PLAY_SVG . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup.
		if ( '' !== $duration ) {
			echo '<span class="cgn-ytp__duration">' . esc_html( $duration ) . '</span>';
		}
		echo '</button>';
	}

	/** Editor-only message; on the live site it becomes an HTML comment so the page never shows an error. */
	private function notice( $message, $is_error = false ) {
		if ( Plugin::is_editor() ) {
			printf(
				'<div class="cgn-ytp-notice%s"><strong>%s</strong> %s</div>',
				$is_error ? ' is-error' : '',
				esc_html__( 'YouTube Playlists:', 'cgn-youtube-playlists' ),
				esc_html( $message )
			);
			return;
		}
		echo '<!-- CGN YouTube Playlists: ' . esc_html( str_replace( '--', '—', $message ) ) . ' -->';
	}

	/* =====================================================================
	 * Helpers
	 * =================================================================== */

	/**
	 * Applies the editor's hide/order choices. Playlists not yet in the saved
	 * order (new ones) keep YouTube's order after the ones that were arranged.
	 *
	 * @param array[] $all  Channel playlists.
	 * @param mixed   $pref Saved control value.
	 * @return array[]
	 */
	private static function visible_playlists( array $all, $pref ) {
		$pref   = is_array( $pref ) ? $pref : array();
		$hidden = isset( $pref['hidden'] ) && is_array( $pref['hidden'] ) ? array_map( 'strval', $pref['hidden'] ) : array();
		$order  = isset( $pref['order'] ) && is_array( $pref['order'] ) ? array_values( array_map( 'strval', $pref['order'] ) ) : array();

		$visible = array_values(
			array_filter(
				$all,
				function ( $playlist ) use ( $hidden ) {
					return ! in_array( $playlist['id'], $hidden, true );
				}
			)
		);

		$position = array_flip( $order );
		$original = array_flip( array_column( $visible, 'id' ) );

		usort(
			$visible,
			function ( $a, $b ) use ( $position, $original ) {
				$pa = $position[ $a['id'] ] ?? PHP_INT_MAX;
				$pb = $position[ $b['id'] ] ?? PHP_INT_MAX;
				if ( $pa === $pb ) {
					return $original[ $a['id'] ] <=> $original[ $b['id'] ];
				}
				return $pa <=> $pb;
			}
		);

		return $visible;
	}

	/** Responsive <img> from YouTube's thumbnail sizes. */
	private static function thumb_img( array $video, $sizes ) {
		$thumbs = (array) ( $video['thumbnails'] ?? array() );
		$widths = array(
			'medium'   => 320,
			'high'     => 480,
			'standard' => 640,
			'maxres'   => 1280,
		);

		$srcset = array();
		$src    = '';
		foreach ( $widths as $size => $width ) {
			if ( empty( $thumbs[ $size ] ) ) {
				continue;
			}
			$srcset[] = esc_url( $thumbs[ $size ] ) . ' ' . $width . 'w';
			if ( '' === $src || 'high' === $size ) {
				$src = $thumbs[ $size ];
			}
		}
		if ( '' === $src && ! empty( $thumbs['default'] ) ) {
			$src = $thumbs['default'];
		}
		if ( '' === $src ) {
			return '';
		}

		return sprintf(
			'<img src="%s"%s sizes="%s" alt="" width="480" height="270" loading="lazy" decoding="async">',
			esc_url( $src ),
			$srcset ? ' srcset="' . esc_attr( implode( ', ', $srcset ) ) . '"' : '',
			esc_attr( $sizes )
		);
	}

	/** PT1H2M3S → 1:02:03, PT4M5S → 4:05. */
	private static function format_duration( $iso ) {
		if ( ! preg_match( '/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/', (string) $iso, $m ) ) {
			return '';
		}
		$hours   = (int) ( $m[1] ?? 0 ) * 24 + (int) ( $m[2] ?? 0 );
		$minutes = (int) ( $m[3] ?? 0 );
		$seconds = (int) ( $m[4] ?? 0 );
		if ( 0 === $hours + $minutes + $seconds ) {
			return '';
		}
		return $hours > 0
			? sprintf( '%d:%02d:%02d', $hours, $minutes, $seconds )
			: sprintf( '%d:%02d', $minutes, $seconds );
	}

	private static function format_date( $iso ) {
		$ts = $iso ? strtotime( (string) $iso ) : false;
		return $ts ? wp_date( get_option( 'date_format' ), $ts ) : '';
	}

	private function meta_line( array $video, array $s ) {
		$parts = array();
		if ( 'yes' === ( $s['show_duration'] ?? 'yes' ) ) {
			$parts[] = self::format_duration( $video['duration'] );
		}
		if ( 'yes' === ( $s['show_date'] ?? 'yes' ) ) {
			$parts[] = self::format_date( $video['published_at'] );
		}
		return implode( ' · ', array_filter( $parts ) );
	}

	/** First ~220 characters of the description. */
	private static function excerpt( $text ) {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
		return wp_html_excerpt( $text, 220, '…' );
	}
}
