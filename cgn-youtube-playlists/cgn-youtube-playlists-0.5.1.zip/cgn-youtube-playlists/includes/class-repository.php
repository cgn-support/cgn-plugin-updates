<?php
/**
 * Channel data with a daily cache.
 *
 * - One cache entry per channel, shared by every widget that shows it.
 * - A "last good copy" is kept in an option, so if YouTube is down or the
 *   quota runs out, widgets keep showing videos instead of going blank.
 * - A short lock stops several simultaneous visitors from all refreshing
 *   the same channel at once when the cache expires.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Repository {

	const PREFIX = 'cgn_ytp_';

	/** Videos cached per playlist. 50 = one API page, so 2 quota units per playlist. */
	const VIDEOS_PER_PLAYLIST = 50;

	/**
	 * Returns:
	 *
	 *     array(
	 *         'channel_id'       => 'UC…',
	 *         'channel_title'    => 'Channel name',
	 *         'uploads_playlist' => 'UU…',
	 *         'playlists'        => array(
	 *             array( 'id' => 'PL…', 'title' => '…', 'count' => 12, 'total' => 14, 'videos' => array( … ) ),
	 *         ),
	 *         'fetched_at'       => 1790900000,
	 *         'stale'            => false, // true when serving the last good copy after a failed refresh
	 *     )
	 *
	 * 'count' is how many videos can actually be shown; 'total' is YouTube's
	 * own item count (it includes private and deleted videos).
	 * Empty playlists are left out.
	 *
	 * @param string $channel_id Channel ID (UC…).
	 * @param bool   $force      Skip the cache and fetch now.
	 * @return array|\WP_Error
	 */
	public static function get_channel( $channel_id, $force = false ) {
		$channel_id = trim( (string) $channel_id );
		if ( ! self::is_valid_channel_id( $channel_id ) ) {
			return new \WP_Error( 'cgn_ytp_bad_channel', __( 'That doesn\'t look like a channel ID. Channel IDs start with UC and are 24 characters long.', 'cgn-youtube-playlists' ) );
		}

		$cache_key  = self::cache_key( $channel_id );
		$backup_key = self::backup_key( $channel_id );
		$lock_key   = $cache_key . '_lock';

		if ( ! $force ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}

			// Someone else is refreshing right now: hand back the last good copy if there is one.
			if ( get_transient( $lock_key ) ) {
				$backup = get_option( $backup_key );
				if ( is_array( $backup ) ) {
					return $backup;
				}
			}
		}

		set_transient( $lock_key, 1, MINUTE_IN_SECONDS );
		$data = self::fetch( $channel_id );
		delete_transient( $lock_key );

		if ( is_wp_error( $data ) ) {
			self::log( $channel_id, $data );

			$backup = get_option( $backup_key );
			if ( is_array( $backup ) ) {
				$backup['stale'] = true;
				// Try again in an hour rather than on every page view.
				set_transient( $cache_key, $backup, HOUR_IN_SECONDS );
				return $backup;
			}
			return $data;
		}

		$ttl = (int) apply_filters( 'cgn_ytp_cache_ttl', DAY_IN_SECONDS, $channel_id );
		set_transient( $cache_key, $data, max( HOUR_IN_SECONDS, $ttl ) );
		update_option( $backup_key, $data, false );

		return $data;
	}

	/** Drops the daily cache so the next request fetches fresh data. The backup copy stays. */
	public static function clear_cache( $channel_id ) {
		if ( self::is_valid_channel_id( $channel_id ) ) {
			delete_transient( self::cache_key( $channel_id ) );
		}
	}

	public static function is_valid_channel_id( $channel_id ) {
		return (bool) preg_match( '/^UC[A-Za-z0-9_-]{22}$/', (string) $channel_id );
	}

	/**
	 * @param string $channel_id Channel ID.
	 * @return array|\WP_Error
	 */
	private static function fetch( $channel_id ) {
		$api = new Api();

		$channel = $api->get_channel_info( $channel_id );
		if ( is_wp_error( $channel ) ) {
			return $channel;
		}

		$playlists = $api->get_channel_playlists( $channel_id );
		if ( is_wp_error( $playlists ) ) {
			return $playlists;
		}

		$limit = max( 1, (int) apply_filters( 'cgn_ytp_videos_per_playlist', self::VIDEOS_PER_PLAYLIST, $channel_id ) );
		$out   = array();

		foreach ( $playlists as $playlist ) {
			if ( $playlist['count'] < 1 ) {
				continue;
			}

			$ids = $api->get_playlist_video_ids( $playlist['id'], $limit );
			if ( is_wp_error( $ids ) ) {
				// A single missing playlist is skipped; anything else (quota, key, network)
				// aborts so a half-finished result never replaces the last good copy.
				if ( self::is_not_found( $ids ) ) {
					continue;
				}
				return $ids;
			}

			$videos = $api->get_videos( $ids );
			if ( is_wp_error( $videos ) ) {
				return $videos;
			}
			if ( empty( $videos ) ) {
				continue;
			}

			$out[] = array(
				'id'     => $playlist['id'],
				'title'  => $playlist['title'],
				'count'  => count( $videos ),
				'total'  => $playlist['count'],
				'videos' => $videos,
			);
		}

		return array(
			'channel_id'       => $channel_id,
			'channel_title'    => $channel['title'],
			'uploads_playlist' => $channel['uploads'],
			'playlists'        => $out,
			'fetched_at'       => time(),
			'stale'            => false,
		);
	}

	private static function is_not_found( \WP_Error $error ) {
		$data = $error->get_error_data();
		return is_array( $data ) && 'playlistNotFound' === ( $data['reason'] ?? '' );
	}

	/** Version is part of the key so a plugin update with a new data shape starts clean. */
	private static function hash( $channel_id ) {
		return md5( $channel_id . '|' . CGN_YTP_VERSION );
	}

	private static function cache_key( $channel_id ) {
		return self::PREFIX . 'ch_' . self::hash( $channel_id );
	}

	private static function backup_key( $channel_id ) {
		return self::PREFIX . 'bk_' . md5( $channel_id );
	}

	private static function log( $channel_id, \WP_Error $error ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( sprintf( '[CGN YouTube Playlists] %s: %s', $channel_id, $error->get_error_message() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		}
	}
}
