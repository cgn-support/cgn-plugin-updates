<?php
/**
 * Settings → YouTube Playlists admin screen.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Settings {

	const PAGE          = 'cgn-youtube-playlists';
	const STATUS_OPTION = 'cgn_ytp_key_status';

	/** @var array<string,bool> Keys already verified during this request. */
	private static $verified = array();

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'admin_post_cgn_ytp_verify_key', array( __CLASS__, 'handle_recheck' ) );
		add_action( 'admin_post_cgn_ytp_remove_key', array( __CLASS__, 'handle_remove' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CGN_YTP_FILE ), array( __CLASS__, 'action_link' ) );
	}

	public static function add_page() {
		add_options_page(
			__( 'YouTube Playlists', 'cgn-youtube-playlists' ),
			__( 'YouTube Playlists', 'cgn-youtube-playlists' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function enqueue( $hook ) {
		if ( 'settings_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_style( 'cgn-ytp-admin', CGN_YTP_URL . 'assets/admin.css', array(), CGN_YTP_VERSION );
	}

	public static function register() {
		register_setting(
			self::PAGE,
			Plugin::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => array(),
			)
		);

		add_settings_section( 'cgn_ytp_api', __( 'YouTube Data API', 'cgn-youtube-playlists' ), array( __CLASS__, 'section_api' ), self::PAGE );
		add_settings_field( 'api_key', __( 'API key', 'cgn-youtube-playlists' ), array( __CLASS__, 'field_api_key' ), self::PAGE, 'cgn_ytp_api', array( 'label_for' => 'cgn-ytp-api-key' ) );

		add_settings_section( 'cgn_ytp_seo', __( 'Search', 'cgn-youtube-playlists' ), '__return_false', self::PAGE );
		add_settings_field( 'schema_enabled', __( 'Video structured data', 'cgn-youtube-playlists' ), array( __CLASS__, 'field_schema' ), self::PAGE, 'cgn_ytp_seo', array( 'label_for' => 'cgn-ytp-schema' ) );
	}

	/**
	 * A blank key field keeps the saved key, so the key is never printed back into the page.
	 * A new key is checked against YouTube as soon as it's saved.
	 *
	 * @param mixed $input Raw submitted values.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$out   = Plugin::get_settings();

		if ( isset( $input['api_key'] ) && '' !== trim( (string) $input['api_key'] ) ) {
			$out['api_key'] = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $input['api_key'] );
			if ( '' !== $out['api_key'] && ! Plugin::api_key_from_constant() ) {
				self::verify_and_store( $out['api_key'] );
			}
		}

		$out['schema_enabled'] = empty( $input['schema_enabled'] ) ? 0 : 1;

		return $out;
	}

	/* ---------------------------------------------------------------------
	 * Key status
	 * ------------------------------------------------------------------- */

	/** Short hash so the stored status can be matched to a key without storing the key twice. */
	private static function fingerprint( $key ) {
		return '' === (string) $key ? '' : substr( hash( 'sha256', (string) $key ), 0, 16 );
	}

	/** Error reasons that mean the key itself is unusable, as opposed to quota or network trouble. */
	const KEY_FAILURES = array(
		'API_KEY_INVALID',
		'keyInvalid',
		'API_KEY_IP_ADDRESS_BLOCKED',
		'ipRefererBlocked',
		'API_KEY_HTTP_REFERRER_BLOCKED',
		'API_KEY_SERVICE_BLOCKED',
		'accessNotConfigured',
		'SERVICE_DISABLED',
	);

	/** Transient set when YouTube couldn't be reached to check the key, to avoid retrying constantly. */
	const RETRY_TRANSIENT = 'cgn_ytp_verify_retry';

	/** How long a "valid" verdict is trusted before it's checked again. */
	const STATUS_MAX_AGE = 3 * DAY_IN_SECONDS;

	private static function is_key_failure( \WP_Error $error ) {
		$data = $error->get_error_data();
		return is_array( $data ) && in_array( $data['reason'] ?? '', self::KEY_FAILURES, true );
	}

	private static function store_status( $key, $state, $message = '' ) {
		update_option(
			self::STATUS_OPTION,
			array(
				'state'       => $state,
				'message'     => $message,
				'checked_at'  => time(),
				'fingerprint' => self::fingerprint( $key ),
			),
			false
		);
		delete_transient( self::RETRY_TRANSIENT );
	}

	/**
	 * Checks a key with YouTube. Quota or network trouble says nothing about the key,
	 * so in that case the stored verdict is left alone and a retry is scheduled.
	 *
	 * @param string $key API key.
	 */
	private static function verify_and_store( $key ) {
		$fingerprint = self::fingerprint( $key );
		if ( isset( self::$verified[ $fingerprint ] ) ) {
			return;
		}
		self::$verified[ $fingerprint ] = true;

		$result = ( new Api( $key ) )->verify();
		if ( ! is_wp_error( $result ) ) {
			self::store_status( $key, 'valid' );
		} elseif ( self::is_key_failure( $result ) ) {
			self::store_status( $key, 'invalid', $result->get_error_message() );
		} else {
			set_transient( self::RETRY_TRANSIENT, $result->get_error_message(), HOUR_IN_SECONDS );
		}
	}

	/**
	 * Keeps the key status current from the plugin's normal YouTube traffic (the daily
	 * refresh), so a deleted or blocked key is noticed without extra API calls.
	 * Called by Api::request() after every request.
	 *
	 * @param string          $key    Key the request used.
	 * @param array|\WP_Error $result Request result.
	 */
	public static function record_api_result( $key, $result ) {
		if ( '' === (string) $key || $key !== Plugin::get_api_key() ) {
			return;
		}
		if ( is_wp_error( $result ) ) {
			if ( self::is_key_failure( $result ) ) {
				self::store_status( $key, 'invalid', $result->get_error_message() );
			}
			return;
		}
		$status = get_option( self::STATUS_OPTION );
		$fresh  = is_array( $status )
			&& 'valid' === ( $status['state'] ?? '' )
			&& ( $status['fingerprint'] ?? '' ) === self::fingerprint( $key )
			&& time() - (int) ( $status['checked_at'] ?? 0 ) < 12 * HOUR_IN_SECONDS;
		if ( ! $fresh ) {
			self::store_status( $key, 'valid' );
		}
	}

	/**
	 * Whether the saved key currently works.
	 *
	 * @param bool $allow_check Re-check with YouTube (1 quota unit) when the verdict is
	 *                          missing or older than STATUS_MAX_AGE. Pass false on hot
	 *                          paths so they never make a network request.
	 * @return bool
	 */
	public static function key_is_active( $allow_check = false ) {
		$key = Plugin::get_api_key();
		if ( '' === $key ) {
			return false;
		}
		$status = self::get_key_status();
		$stale  = empty( $status['checked_at'] ) || time() - (int) $status['checked_at'] > self::STATUS_MAX_AGE;

		if ( $allow_check && $stale && ! get_transient( self::RETRY_TRANSIENT ) ) {
			self::verify_and_store( $key );
			$status = self::get_key_status();
		}
		return 'valid' === $status['state'];
	}

	/**
	 * @return array{state:string,message?:string,checked_at?:int}
	 *         state is none, unchecked, valid or invalid.
	 */
	public static function get_key_status() {
		$key = Plugin::get_api_key();
		if ( '' === $key ) {
			return array( 'state' => 'none' );
		}
		$status = get_option( self::STATUS_OPTION );
		if ( ! is_array( $status ) || ( $status['fingerprint'] ?? '' ) !== self::fingerprint( $key ) ) {
			return array( 'state' => 'unchecked' );
		}
		return $status;
	}

	public static function handle_recheck() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'cgn-youtube-playlists' ) );
		}
		check_admin_referer( 'cgn_ytp_verify_key' );

		$key = Plugin::get_api_key();
		if ( '' !== $key ) {
			delete_transient( self::RETRY_TRANSIENT );
			self::verify_and_store( $key );
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::PAGE . '&cgn_ytp_notice=checked' ) );
		exit;
	}

	public static function handle_remove() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'cgn-youtube-playlists' ) );
		}
		check_admin_referer( 'cgn_ytp_remove_key' );

		$settings            = Plugin::get_settings();
		$settings['api_key'] = '';
		// Write directly so the sanitize callback doesn't read the old key back in.
		remove_all_filters( 'sanitize_option_' . Plugin::OPTION );
		update_option( Plugin::OPTION, $settings );
		delete_option( self::STATUS_OPTION );

		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::PAGE . '&cgn_ytp_notice=removed' ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Fields
	 * ------------------------------------------------------------------- */

	public static function section_api() {
		printf(
			'<p>%s <a href="%s" target="_blank" rel="noopener noreferrer">%s</a></p>',
			esc_html__( 'Create a key in Google Cloud with the YouTube Data API v3 enabled.', 'cgn-youtube-playlists' ),
			esc_url( 'https://console.cloud.google.com/apis/credentials' ),
			esc_html__( 'Open Google Cloud credentials', 'cgn-youtube-playlists' )
		);
	}

	public static function field_api_key() {
		$key           = Plugin::get_api_key();
		$from_constant = Plugin::api_key_from_constant();
		$name          = Plugin::OPTION . '[api_key]';

		// Empty state: just the field.
		if ( '' === $key ) {
			printf(
				'<input type="password" id="cgn-ytp-api-key" name="%s" value="" class="regular-text" autocomplete="off" spellcheck="false" placeholder="%s">',
				esc_attr( $name ),
				esc_attr__( 'Paste your API key', 'cgn-youtube-playlists' )
			);
			echo '<p class="description">'
				. esc_html__( "Save Changes to connect. In Google Cloud, restrict the key to the YouTube Data API v3 and to this server's IP address.", 'cgn-youtube-playlists' )
				. '</p>';
			return;
		}

		$status = self::get_key_status();
		$state  = $status['state'];
		$labels = array(
			'valid'     => array( 'yes-alt', __( 'Your YouTube API key is active.', 'cgn-youtube-playlists' ) ),
			'invalid'   => array( 'warning', __( 'YouTube rejected this key.', 'cgn-youtube-playlists' ) ),
			'unchecked' => array( 'clock', __( "This key hasn't been checked yet.", 'cgn-youtube-playlists' ) ),
		);
		$label  = $labels[ $state ] ?? $labels['unchecked'];

		echo '<div class="cgn-ytp-key cgn-ytp-key--' . esc_attr( $state ) . '">';

		printf(
			'<p class="cgn-ytp-key__status"><span class="dashicons dashicons-%s" aria-hidden="true"></span><strong>%s</strong></p>',
			esc_attr( $label[0] ),
			esc_html( $label[1] )
		);
		if ( 'invalid' === $state && ! empty( $status['message'] ) ) {
			echo '<p class="cgn-ytp-key__error">' . esc_html( $status['message'] ) . '</p>';
		}

		echo '<div class="cgn-ytp-key__row">';
		printf(
			'<div class="cgn-ytp-key__field"><span class="cgn-ytp-key__mask" aria-label="%s">%s</span>%s</div>',
			/* translators: %s: last four characters of the API key. */
			esc_attr( sprintf( __( 'Saved key ending in %s', 'cgn-youtube-playlists' ), substr( $key, -4 ) ) ),
			esc_html( str_repeat( '•', 16 ) . substr( $key, -4 ) ),
			'valid' === $state ? '<span class="dashicons dashicons-yes-alt cgn-ytp-key__check" aria-hidden="true"></span>' : ''
		);
		if ( ! $from_constant ) {
			printf(
				'<a class="button" href="%s" onclick="return confirm(\'%s\');">%s</a>',
				esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=cgn_ytp_remove_key' ), 'cgn_ytp_remove_key' ) ),
				esc_js( __( 'Remove the saved API key? Widgets will keep showing cached videos but stop updating.', 'cgn-youtube-playlists' ) ),
				esc_html__( 'Remove key', 'cgn-youtube-playlists' )
			);
		}
		echo '</div>';

		$meta = array();
		if ( ! empty( $status['checked_at'] ) ) {
			/* translators: %s: date and time. */
			$meta[] = esc_html( sprintf( __( 'Last checked %s', 'cgn-youtube-playlists' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $status['checked_at'] ) ) );
		}
		$meta[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=cgn_ytp_verify_key' ), 'cgn_ytp_verify_key' ) ),
			'unchecked' === $state ? esc_html__( 'Check now', 'cgn-youtube-playlists' ) : esc_html__( 'Re-check', 'cgn-youtube-playlists' )
		);
		if ( $from_constant ) {
			$meta[] = esc_html__( 'Set in wp-config.php', 'cgn-youtube-playlists' );
		}
		echo '<p class="cgn-ytp-key__meta">' . implode( ' · ', $meta ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- each piece escaped above.

		if ( ! $from_constant ) {
			echo '<details class="cgn-ytp-key__change"><summary>' . esc_html__( 'Replace with a different key', 'cgn-youtube-playlists' ) . '</summary>';
			printf(
				'<input type="password" id="cgn-ytp-api-key" name="%s" value="" class="regular-text" autocomplete="off" spellcheck="false" placeholder="%s">',
				esc_attr( $name ),
				esc_attr__( 'Paste the new key, then Save Changes', 'cgn-youtube-playlists' )
			);
			echo '</details>';
		}

		echo '</div>';
	}

	public static function field_schema() {
		printf(
			'<label><input type="checkbox" id="cgn-ytp-schema" name="%s[schema_enabled]" value="1" %s> %s</label>',
			esc_attr( Plugin::OPTION ),
			checked( 1, (int) Plugin::get_settings()['schema_enabled'], false ),
			esc_html__( 'Add VideoObject markup for videos shown by the widget', 'cgn-youtube-playlists' )
		);
		echo '<p class="description">'
			. esc_html__( 'Helps the videos appear in Google video results. Turn this off if another plugin already outputs video schema for these videos.', 'cgn-youtube-playlists' )
			. '</p>';
	}

	/* ---------------------------------------------------------------------
	 * Page
	 * ------------------------------------------------------------------- */

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$notice = isset( $_GET['cgn_ytp_notice'] ) ? sanitize_key( wp_unslash( $_GET['cgn_ytp_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap cgn-ytp-settings">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			<?php if ( 'checked' === $notice && get_transient( self::RETRY_TRANSIENT ) ) : ?>
				<div class="notice notice-warning is-dismissible"><p><?php echo esc_html( sprintf( /* translators: %s: error message. */ __( "Couldn't reach YouTube to check the key, so its status is unchanged: %s", 'cgn-youtube-playlists' ), get_transient( self::RETRY_TRANSIENT ) ) ); ?></p></div>
			<?php elseif ( 'checked' === $notice ) : ?>
				<div class="notice notice-info is-dismissible"><p><?php esc_html_e( 'Key checked with YouTube.', 'cgn-youtube-playlists' ); ?></p></div>
			<?php elseif ( 'removed' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'API key removed.', 'cgn-youtube-playlists' ); ?></p></div>
			<?php endif; ?>

			<form action="options.php" method="post">
				<?php
				settings_fields( self::PAGE );
				do_settings_sections( self::PAGE );
				submit_button();
				?>
			</form>

			<?php self::render_test_tool(); ?>
		</div>
		<?php
	}

	/**
	 * "Test a channel" tool: runs the same fetch the widget will use and shows what came back.
	 */
	private static function render_test_tool() {
		$channel = '';
		$force   = false;
		$valid   = false;

		if ( isset( $_GET['cgn_ytp_channel'], $_GET['_cgn_ytp_nonce'] ) ) {
			$valid   = (bool) wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_cgn_ytp_nonce'] ) ), 'cgn_ytp_test' );
			$channel = sanitize_text_field( wp_unslash( $_GET['cgn_ytp_channel'] ) );
			$force   = ! empty( $_GET['cgn_ytp_force'] );
		}
		?>
		<hr>
		<h2><?php esc_html_e( 'Test a channel', 'cgn-youtube-playlists' ); ?></h2>
		<p><?php esc_html_e( 'Pulls a channel the same way the widget will, so you can confirm the key and see which playlists come through.', 'cgn-youtube-playlists' ); ?></p>

		<form method="get" action="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>" class="cgn-ytp-test">
			<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE ); ?>">
			<?php wp_nonce_field( 'cgn_ytp_test', '_cgn_ytp_nonce', false ); ?>
			<label for="cgn-ytp-channel" class="screen-reader-text"><?php esc_html_e( 'Channel ID', 'cgn-youtube-playlists' ); ?></label>
			<input type="text" id="cgn-ytp-channel" name="cgn_ytp_channel" class="regular-text" value="<?php echo esc_attr( $channel ); ?>" placeholder="UC…" spellcheck="false">
			<label><input type="checkbox" name="cgn_ytp_force" value="1" <?php checked( $force ); ?>> <?php esc_html_e( 'Skip the cache and fetch fresh', 'cgn-youtube-playlists' ); ?></label>
			<?php submit_button( __( 'Test channel', 'cgn-youtube-playlists' ), 'secondary', '', false ); ?>
		</form>
		<?php

		if ( '' === $channel ) {
			return;
		}
		if ( ! $valid ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'That link has expired. Run the test again.', 'cgn-youtube-playlists' ) . '</p></div>';
			return;
		}

		$data = Repository::get_channel( $channel, $force );
		if ( is_wp_error( $data ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $data->get_error_message() ) . '</p></div>';
			return;
		}

		self::render_test_results( $data );
	}

	private static function render_test_results( array $data ) {
		$age   = time() - (int) $data['fetched_at'];
		$fresh = $age < 30;
		?>
		<div class="cgn-ytp-results">
			<h3><?php echo esc_html( $data['channel_title'] ); ?></h3>
			<p class="cgn-ytp-results__meta">
				<?php
				echo esc_html(
					$fresh
						? __( 'Fetched fresh from YouTube just now.', 'cgn-youtube-playlists' )
						/* translators: %s: human time difference, e.g. "3 hours". */
						: sprintf( __( 'Served from the cache, fetched %s ago. It refreshes automatically once a day.', 'cgn-youtube-playlists' ), human_time_diff( (int) $data['fetched_at'] ) )
				);
				?>
			</p>

			<?php if ( ! empty( $data['stale'] ) ) : ?>
				<div class="notice notice-warning inline"><p><?php esc_html_e( "The last refresh failed, so this is the last good copy. Widgets keep showing it and will retry within the hour.", 'cgn-youtube-playlists' ); ?></p></div>
			<?php endif; ?>

			<?php if ( empty( $data['playlists'] ) ) : ?>
				<p><?php esc_html_e( 'No public playlists with videos were found on this channel.', 'cgn-youtube-playlists' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Playlist', 'cgn-youtube-playlists' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Videos', 'cgn-youtube-playlists' ); ?></th>
							<th scope="col"><?php esc_html_e( 'First video in playlist', 'cgn-youtube-playlists' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Playlist ID', 'cgn-youtube-playlists' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $data['playlists'] as $playlist ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $playlist['title'] ); ?></strong></td>
								<td>
									<?php
									echo esc_html( (string) $playlist['count'] );
									if ( $playlist['total'] > $playlist['count'] ) {
										/* translators: %d: YouTube's total item count for the playlist. */
										echo ' <span class="description">' . esc_html( sprintf( __( '(of %d on YouTube)', 'cgn-youtube-playlists' ), $playlist['total'] ) ) . '</span>';
									}
									?>
								</td>
								<td><?php echo esc_html( $playlist['videos'][0]['title'] ?? '' ); ?></td>
								<td><code><?php echo esc_html( $playlist['id'] ); ?></code></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Adds a Settings link on the Plugins screen.
	 *
	 * @param string[] $links Existing action links.
	 * @return string[]
	 */
	public static function action_link( $links ) {
		array_unshift(
			$links,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ),
				esc_html__( 'Settings', 'cgn-youtube-playlists' )
			)
		);
		return $links;
	}
}
