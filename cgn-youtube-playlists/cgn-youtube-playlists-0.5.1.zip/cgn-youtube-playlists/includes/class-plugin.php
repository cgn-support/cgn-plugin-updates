<?php
/**
 * Plugin bootstrap.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** Option name holding all plugin settings. */
	const OPTION = 'cgn_ytp_settings';

	/** @var Plugin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		Settings::init();
		Schema::init();
		Rest::init();

		if ( did_action( 'elementor/loaded' ) ) {
			add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
			add_action( 'elementor/controls/register', array( $this, 'register_controls' ) );
			add_action( 'elementor/frontend/after_register_styles', array( $this, 'register_styles' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_scripts' ) );
		} elseif ( is_admin() ) {
			add_action( 'admin_notices', array( $this, 'notice_missing_elementor' ) );
		}
	}

	/**
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor's widget registry.
	 */
	public function register_widgets( $widgets_manager ) {
		require_once CGN_YTP_PATH . 'includes/class-widget.php';
		$widgets_manager->register( new Widget() );
	}

	/**
	 * @param \Elementor\Controls_Manager $controls_manager Elementor's control registry.
	 */
	public function register_controls( $controls_manager ) {
		require_once CGN_YTP_PATH . 'includes/class-playlists-control.php';
		$controls_manager->register( new Playlists_Control() );
	}

	/** Front-end styles: one shared file plus one per layout, so a page only loads what it uses. */
	public function register_styles() {
		$url = CGN_YTP_URL . 'assets/';
		wp_register_style( 'cgn-ytp-base', $url . 'ytp-base.css', array(), CGN_YTP_VERSION );
		wp_register_style( 'cgn-ytp-grid', $url . 'ytp-grid.css', array( 'cgn-ytp-base' ), CGN_YTP_VERSION );
		wp_register_style( 'cgn-ytp-carousel', $url . 'ytp-carousel.css', array( 'cgn-ytp-base' ), CGN_YTP_VERSION );
		wp_register_style( 'cgn-ytp-featured', $url . 'ytp-featured.css', array( 'cgn-ytp-base' ), CGN_YTP_VERSION );
	}

	public function register_scripts() {
		$url = CGN_YTP_URL . 'assets/';
		wp_register_script( 'cgn-ytp-core', $url . 'ytp-core.js', array(), CGN_YTP_VERSION, true );
		wp_register_script( 'cgn-ytp-carousel', $url . 'ytp-carousel.js', array( 'cgn-ytp-core' ), CGN_YTP_VERSION, true );
	}

	/** True inside the Elementor editor, its preview iframe, or its AJAX re-renders. */
	public static function is_editor() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}
		$elementor = \Elementor\Plugin::$instance;
		return ( isset( $elementor->editor ) && $elementor->editor->is_edit_mode() )
			|| ( isset( $elementor->preview ) && $elementor->preview->is_preview_mode() );
	}

	public function notice_missing_elementor() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>'
			. esc_html__( 'CGN YouTube Playlists needs Elementor to be installed and active.', 'cgn-youtube-playlists' )
			. '</p></div>';
	}

	/**
	 * Saved settings merged over defaults.
	 *
	 * @return array{api_key:string,schema_enabled:int}
	 */
	public static function get_settings() {
		$defaults = array(
			'api_key'        => '',
			'schema_enabled' => 1,
		);
		$saved    = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	}

	/** True when the key is defined in wp-config.php rather than saved in the database. */
	public static function api_key_from_constant() {
		return defined( 'CGN_YTP_API_KEY' ) && CGN_YTP_API_KEY;
	}

	/** The API key to use: wp-config.php constant first, then the saved setting. */
	public static function get_api_key() {
		if ( self::api_key_from_constant() ) {
			return (string) CGN_YTP_API_KEY;
		}
		return (string) self::get_settings()['api_key'];
	}
}
