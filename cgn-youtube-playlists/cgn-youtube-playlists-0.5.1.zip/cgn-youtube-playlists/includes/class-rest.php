<?php
/**
 * Editor-only REST endpoint for the playlist toggle control.
 *
 * GET  /wp-json/cgn-ytp/v1/playlists?channel=UC…   cached list
 * POST /wp-json/cgn-ytp/v1/playlists  channel=UC…  clears the cache and refetches
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Rest {

	const NS = 'cgn-ytp/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$args = array(
			'channel' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
		);

		register_rest_route(
			self::NS,
			'/playlists',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'get_playlists' ),
					'permission_callback' => array( __CLASS__, 'can_edit' ),
					'args'                => $args,
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'refresh' ),
					'permission_callback' => array( __CLASS__, 'can_edit' ),
					'args'                => $args,
				),
			)
		);
	}

	public static function can_edit() {
		return current_user_can( 'edit_posts' );
	}

	public static function get_playlists( \WP_REST_Request $request ) {
		return self::respond( Repository::get_channel( $request['channel'] ) );
	}

	public static function refresh( \WP_REST_Request $request ) {
		Repository::clear_cache( $request['channel'] );
		return self::respond( Repository::get_channel( $request['channel'], true ) );
	}

	/**
	 * @param array|\WP_Error $data Repository result.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private static function respond( $data ) {
		if ( is_wp_error( $data ) ) {
			return new \WP_Error( 'cgn_ytp_error', $data->get_error_message(), array( 'status' => 400 ) );
		}

		$playlists = array();
		foreach ( $data['playlists'] as $playlist ) {
			$playlists[] = array(
				'id'    => $playlist['id'],
				'title' => $playlist['title'],
				'count' => (int) $playlist['count'],
			);
		}

		return rest_ensure_response(
			array(
				'channel_title' => $data['channel_title'],
				'fetched_at'    => (int) $data['fetched_at'],
				'fetched_human' => human_time_diff( (int) $data['fetched_at'] ),
				'stale'         => ! empty( $data['stale'] ),
				'playlists'     => $playlists,
			)
		);
	}
}
