<?php
/**
 * Elementor control that lists a channel's playlists with on/off switches
 * and drag-to-reorder. The list itself is built by assets/editor.js.
 *
 * Saved value: array( 'hidden' => string[], 'order' => string[], 'v' => int )
 * Storing what's hidden (not what's shown) means new playlists appear on their own.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

use Elementor\Base_Data_Control;

defined( 'ABSPATH' ) || exit;

class Playlists_Control extends Base_Data_Control {

	const TYPE = 'cgn_ytp_playlists';

	public function get_type() {
		return self::TYPE;
	}

	public function get_default_value() {
		return array(
			'hidden' => array(),
			'order'  => array(),
		);
	}

	protected function get_default_settings() {
		return array(
			'label_block'     => true,
			'channel_control' => 'channel_id',
		);
	}

	public function enqueue() {
		wp_enqueue_style( 'cgn-ytp-editor', CGN_YTP_URL . 'assets/editor.css', array(), CGN_YTP_VERSION );
		wp_enqueue_script( 'cgn-ytp-editor', CGN_YTP_URL . 'assets/editor.js', array( 'jquery', 'jquery-ui-sortable', 'underscore' ), CGN_YTP_VERSION, true );
		wp_localize_script(
			'cgn-ytp-editor',
			'cgnYtpEditor',
			array(
				'restUrl' => esc_url_raw( rest_url( Rest::NS . '/playlists' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'enterChannel' => __( 'Add a channel ID above to load its playlists.', 'cgn-youtube-playlists' ),
					'badChannel'   => __( 'Channel IDs start with UC and are 24 characters long.', 'cgn-youtube-playlists' ),
					'loading'      => __( 'Loading playlists…', 'cgn-youtube-playlists' ),
					'refreshing'   => __( 'Fetching fresh videos from YouTube…', 'cgn-youtube-playlists' ),
					/* translators: 1: channel name, 2: number of playlists, 3: time ago. */
					'summary'      => __( '%1$s · %2$s playlists · updated %3$s ago', 'cgn-youtube-playlists' ),
					'stale'        => __( 'The last refresh failed, so this is the last good copy.', 'cgn-youtube-playlists' ),
					'none'         => __( 'This channel has no public playlists with videos.', 'cgn-youtube-playlists' ),
					'error'        => __( 'Could not load playlists.', 'cgn-youtube-playlists' ),
					'video'        => __( 'video', 'cgn-youtube-playlists' ),
					'videos'       => __( 'videos', 'cgn-youtube-playlists' ),
					'show'         => __( 'Show', 'cgn-youtube-playlists' ),
					'drag'         => __( 'Drag to reorder', 'cgn-youtube-playlists' ),
				),
			)
		);
	}

	public function content_template() {
		?>
		<div class="elementor-control-field cgn-ytp-pl">
			<# if ( data.label ) { #>
				<label class="elementor-control-title">{{{ data.label }}}</label>
			<# } #>
			<p class="cgn-ytp-pl__status" aria-live="polite"></p>
			<ul class="cgn-ytp-pl__list"></ul>
			<button type="button" class="cgn-ytp-pl__refresh">
				<i class="eicon-sync" aria-hidden="true"></i>
				<?php esc_html_e( 'Refresh videos now', 'cgn-youtube-playlists' ); ?>
			</button>
		</div>
		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}
}
