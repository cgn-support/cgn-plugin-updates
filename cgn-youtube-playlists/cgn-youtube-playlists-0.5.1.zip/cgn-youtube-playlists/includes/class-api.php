<?php
/**
 * Thin YouTube Data API v3 client.
 *
 * Every public method returns plain arrays or a WP_Error with a message
 * written for the person reading the settings screen.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Api {

	const BASE = 'https://www.googleapis.com/youtube/v3/';

	/** Safety cap on pagination: 10 pages × 50 = 500 items. */
	const MAX_PAGES = 10;

	/** Longest description kept per video (keeps the cache small). */
	const MAX_DESCRIPTION = 1000;

	/** @var string */
	private $key;

	/**
	 * @param string|null $key API key to use; null uses the saved key.
	 */
	public function __construct( $key = null ) {
		$this->key = null === $key ? Plugin::get_api_key() : (string) $key;
	}

	public function has_key() {
		return '' !== $this->key;
	}

	/**
	 * Confirms the key works with a 1-unit request.
	 *
	 * @return true|\WP_Error
	 */
	public function verify() {
		$body = $this->request( 'videoCategories', array( 'part' => 'snippet', 'regionCode' => 'US' ) );
		return is_wp_error( $body ) ? $body : true;
	}

	/**
	 * Channel title and its uploads playlist ID.
	 *
	 * @param string $channel_id Channel ID (UC…).
	 * @return array{title:string,uploads:string}|\WP_Error
	 */
	public function get_channel_info( $channel_id ) {
		$body = $this->request( 'channels', array( 'part' => 'snippet,contentDetails', 'id' => $channel_id ) );
		if ( is_wp_error( $body ) ) {
			return $body;
		}
		if ( empty( $body['items'][0] ) ) {
			return new \WP_Error( 'cgn_ytp_channelNotFound', __( 'YouTube has no channel with that ID. Double-check it in YouTube Studio under Settings → Channel → Advanced settings.', 'cgn-youtube-playlists' ) );
		}
		$item = $body['items'][0];
		return array(
			'title'   => (string) ( $item['snippet']['title'] ?? '' ),
			'uploads' => (string) ( $item['contentDetails']['relatedPlaylists']['uploads'] ?? '' ),
		);
	}

	/**
	 * Every public playlist on a channel.
	 *
	 * @param string $channel_id Channel ID.
	 * @return array[]|\WP_Error Each: id, title, count (YouTube's itemCount).
	 */
	public function get_channel_playlists( $channel_id ) {
		$playlists = array();
		$token     = '';

		for ( $page = 0; $page < self::MAX_PAGES; $page++ ) {
			$params = array(
				'part'       => 'snippet,contentDetails,status',
				'channelId'  => $channel_id,
				'maxResults' => 50,
			);
			if ( $token ) {
				$params['pageToken'] = $token;
			}

			$body = $this->request( 'playlists', $params );
			if ( is_wp_error( $body ) ) {
				return $body;
			}

			foreach ( (array) ( $body['items'] ?? array() ) as $item ) {
				if ( isset( $item['status']['privacyStatus'] ) && 'public' !== $item['status']['privacyStatus'] ) {
					continue;
				}
				$playlists[] = array(
					'id'    => (string) $item['id'],
					'title' => (string) ( $item['snippet']['title'] ?? '' ),
					'count' => (int) ( $item['contentDetails']['itemCount'] ?? 0 ),
				);
			}

			$token = (string) ( $body['nextPageToken'] ?? '' );
			if ( '' === $token ) {
				break;
			}
		}

		return $playlists;
	}

	/**
	 * Video IDs in a playlist, in playlist order.
	 *
	 * @param string $playlist_id Playlist ID.
	 * @param int    $limit       Most IDs to return.
	 * @return string[]|\WP_Error
	 */
	public function get_playlist_video_ids( $playlist_id, $limit = 50 ) {
		$ids   = array();
		$token = '';

		for ( $page = 0; $page < self::MAX_PAGES && count( $ids ) < $limit; $page++ ) {
			$params = array(
				'part'       => 'contentDetails',
				'playlistId' => $playlist_id,
				'maxResults' => min( 50, $limit - count( $ids ) ),
			);
			if ( $token ) {
				$params['pageToken'] = $token;
			}

			$body = $this->request( 'playlistItems', $params );
			if ( is_wp_error( $body ) ) {
				return $body;
			}

			foreach ( (array) ( $body['items'] ?? array() ) as $item ) {
				$id = (string) ( $item['contentDetails']['videoId'] ?? '' );
				if ( '' !== $id && ! in_array( $id, $ids, true ) ) {
					$ids[] = $id;
				}
			}

			$token = (string) ( $body['nextPageToken'] ?? '' );
			if ( '' === $token ) {
				break;
			}
		}

		return $ids;
	}

	/**
	 * Full details for videos, keeping the order of $ids. Drops private,
	 * deleted, non-embeddable and upcoming (not yet premiered) videos.
	 *
	 * @param string[] $ids Video IDs.
	 * @return array[]|\WP_Error Normalized videos (see normalize_video()).
	 */
	public function get_videos( array $ids ) {
		$allowed = (array) apply_filters( 'cgn_ytp_allowed_privacy', array( 'public', 'unlisted' ) );
		$found   = array();

		foreach ( array_chunk( array_values( array_unique( $ids ) ), 50 ) as $chunk ) {
			$body = $this->request(
				'videos',
				array(
					'part'       => 'snippet,contentDetails,status',
					'id'         => implode( ',', $chunk ),
					'maxResults' => 50,
				)
			);
			if ( is_wp_error( $body ) ) {
				return $body;
			}

			foreach ( (array) ( $body['items'] ?? array() ) as $item ) {
				$status = (array) ( $item['status'] ?? array() );
				if ( ! in_array( $status['privacyStatus'] ?? '', $allowed, true ) ) {
					continue;
				}
				if ( isset( $status['embeddable'] ) && ! $status['embeddable'] ) {
					continue;
				}
				if ( 'upcoming' === ( $item['snippet']['liveBroadcastContent'] ?? 'none' ) ) {
					continue;
				}
				$found[ (string) $item['id'] ] = self::normalize_video( $item );
			}
		}

		$ordered = array();
		foreach ( $ids as $id ) {
			if ( isset( $found[ $id ] ) ) {
				$ordered[] = $found[ $id ];
			}
		}
		return $ordered;
	}

	/**
	 * GET an endpoint and decode it.
	 *
	 * @param string $endpoint e.g. "playlists".
	 * @param array  $params   Query parameters (the key is added here).
	 * @return array|\WP_Error
	 */
	public function request( $endpoint, array $params ) {
		if ( ! $this->has_key() ) {
			return new \WP_Error( 'cgn_ytp_no_key', __( 'No YouTube API key is saved. Add one under Settings → YouTube Playlists.', 'cgn-youtube-playlists' ) );
		}

		$params['key'] = $this->key;
		$url           = self::BASE . $endpoint . '?' . http_build_query( $params, '', '&', PHP_QUERY_RFC3986 );

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 15,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			/* translators: %s: connection error from WordPress. */
			return new \WP_Error( 'cgn_ytp_http', sprintf( __( 'Could not reach YouTube: %s', 'cgn-youtube-playlists' ), $response->get_error_message() ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		$result = ( 200 !== $code || ! is_array( $body ) )
			? self::error_from_response( $code, is_array( $body ) ? $body : array() )
			: $body;

		Settings::record_api_result( $this->key, $result );
		return $result;
	}

	/**
	 * Turns Google's error payload into a readable WP_Error. The reason
	 * (e.g. quotaExceeded) is kept in the error data for callers.
	 *
	 * @param int   $code HTTP status.
	 * @param array $body Decoded body.
	 * @return \WP_Error
	 */
	private static function error_from_response( $code, array $body ) {
		$error   = isset( $body['error'] ) && is_array( $body['error'] ) ? $body['error'] : array();
		$reasons = array();
		foreach ( array( 'errors', 'details' ) as $list ) {
			foreach ( (array) ( $error[ $list ] ?? array() ) as $item ) {
				if ( is_array( $item ) && ! empty( $item['reason'] ) ) {
					$reasons[] = (string) $item['reason'];
				}
			}
		}

		$invalid  = __( 'The API key is not valid. Copy it again from Google Cloud → APIs & Services → Credentials.', 'cgn-youtube-playlists' );
		$disabled = __( 'YouTube Data API v3 is not enabled for this key\'s Google Cloud project. Enable it under APIs & Services → Library.', 'cgn-youtube-playlists' );
		$ip       = __( 'The key\'s IP restriction is blocking this server. Add this server\'s IP address to the key in Google Cloud, or remove the IP restriction while testing.', 'cgn-youtube-playlists' );
		$referrer = __( 'The key is restricted to HTTP referrers, which blocks server requests. Change the application restriction to IP addresses (or none).', 'cgn-youtube-playlists' );
		$blocked  = __( 'The key\'s API restrictions don\'t include YouTube Data API v3. Add it under the key\'s API restrictions.', 'cgn-youtube-playlists' );
		$quota    = __( 'The daily YouTube API quota for this key is used up. It resets at midnight Pacific time; cached videos keep showing until then.', 'cgn-youtube-playlists' );
		$missing  = __( 'YouTube could not find that channel or playlist.', 'cgn-youtube-playlists' );

		$map = array(
			'API_KEY_INVALID'               => $invalid,
			'keyInvalid'                    => $invalid,
			'accessNotConfigured'           => $disabled,
			'SERVICE_DISABLED'              => $disabled,
			'API_KEY_IP_ADDRESS_BLOCKED'    => $ip,
			'ipRefererBlocked'              => $ip,
			'API_KEY_HTTP_REFERRER_BLOCKED' => $referrer,
			'API_KEY_SERVICE_BLOCKED'       => $blocked,
			'quotaExceeded'                 => $quota,
			'dailyLimitExceeded'            => $quota,
			'channelNotFound'               => $missing,
			'playlistNotFound'              => $missing,
		);

		foreach ( $reasons as $reason ) {
			if ( isset( $map[ $reason ] ) ) {
				return new \WP_Error( 'cgn_ytp_api', $map[ $reason ], array( 'status' => $code, 'reason' => $reason ) );
			}
		}

		$message = ! empty( $error['message'] )
			? wp_strip_all_tags( (string) $error['message'] )
			/* translators: %d: HTTP status code. */
			: sprintf( __( 'YouTube returned an unexpected response (HTTP %d).', 'cgn-youtube-playlists' ), $code );

		return new \WP_Error( 'cgn_ytp_api', $message, array( 'status' => $code, 'reason' => $reasons[0] ?? '' ) );
	}

	/**
	 * The video shape used everywhere else in the plugin (cache, widget, schema).
	 *
	 * @param array $item videos.list item.
	 * @return array{id:string,title:string,description:string,published_at:string,duration:string,thumbnails:array}
	 */
	private static function normalize_video( array $item ) {
		$snippet = (array) ( $item['snippet'] ?? array() );

		$thumbs = array();
		foreach ( (array) ( $snippet['thumbnails'] ?? array() ) as $size => $thumb ) {
			if ( is_array( $thumb ) && ! empty( $thumb['url'] ) ) {
				$thumbs[ (string) $size ] = (string) $thumb['url'];
			}
		}

		$description = (string) ( $snippet['description'] ?? '' );
		if ( function_exists( 'mb_substr' ) ) {
			$description = mb_substr( $description, 0, self::MAX_DESCRIPTION );
		} else {
			$description = substr( $description, 0, self::MAX_DESCRIPTION );
		}

		return array(
			'id'           => (string) $item['id'],
			'title'        => (string) ( $snippet['title'] ?? '' ),
			'description'  => $description,
			'published_at' => (string) ( $snippet['publishedAt'] ?? '' ),
			'duration'     => (string) ( $item['contentDetails']['duration'] ?? '' ),
			'thumbnails'   => $thumbs,
		);
	}
}
