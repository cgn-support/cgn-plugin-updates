<?php
/**
 * VideoObject structured data.
 *
 * Widgets call Schema::add_videos() while rendering. Videos are de-duplicated by
 * ID across every widget on the page, then printed as one JSON-LD block in the footer.
 *
 * Video shape expected from the data layer (phase 2):
 *
 *     array(
 *         'id'           => 'abc123XYZ_-',
 *         'title'        => 'Walnut & White Oak Kitchen Reveal',
 *         'description'  => 'Full YouTube description',
 *         'published_at' => '2026-09-22T14:00:00Z', // videos.list snippet.publishedAt (the publish date)
 *         'duration'     => 'PT12M48S',             // contentDetails.duration (ISO 8601)
 *         'thumbnails'   => array( 'maxres' => 'https://…', 'high' => 'https://…' ),
 *     )
 *
 * Filters:
 *  - cgn_ytp_schema_enabled (bool)            Turn output on or off in code.
 *  - cgn_ytp_schema_video   (array, $video)   Adjust or drop (return null) one VideoObject.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Schema {

	/** Longest description kept in the markup. */
	const MAX_DESCRIPTION = 500;

	/** @var array<string,array> VideoObject nodes keyed by video ID. */
	private static $nodes = array();

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'print_json_ld' ), 20 );
	}

	public static function is_enabled() {
		$enabled = (bool) Plugin::get_settings()['schema_enabled'];
		return (bool) apply_filters( 'cgn_ytp_schema_enabled', $enabled );
	}

	/**
	 * Queue videos that a widget rendered on this page.
	 *
	 * @param array[] $videos Videos in the shape documented above.
	 */
	public static function add_videos( array $videos ) {
		if ( ! self::is_enabled() ) {
			return;
		}
		foreach ( $videos as $video ) {
			if ( ! is_array( $video ) || empty( $video['id'] ) || isset( self::$nodes[ $video['id'] ] ) ) {
				continue;
			}
			$node = self::build_node( $video );
			if ( $node ) {
				self::$nodes[ $video['id'] ] = $node;
			}
		}
	}

	/**
	 * One VideoObject, or null when Google's required fields
	 * (name, thumbnailUrl, uploadDate) cannot all be filled.
	 *
	 * @param array $video Video data.
	 * @return array|null
	 */
	public static function build_node( array $video ) {
		$id     = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $video['id'] );
		$title  = isset( $video['title'] ) ? trim( wp_strip_all_tags( (string) $video['title'] ) ) : '';
		$thumbs = self::thumbnail_urls( isset( $video['thumbnails'] ) ? (array) $video['thumbnails'] : array() );
		$upload = self::iso_date( isset( $video['published_at'] ) ? (string) $video['published_at'] : '' );

		if ( '' === $id || '' === $title || empty( $thumbs ) || '' === $upload ) {
			return null;
		}

		$description = self::clean_description( isset( $video['description'] ) ? (string) $video['description'] : '' );

		$node = array(
			'@type'        => 'VideoObject',
			'name'         => $title,
			'description'  => '' !== $description ? $description : $title,
			'thumbnailUrl' => $thumbs,
			'uploadDate'   => $upload,
			'embedUrl'     => 'https://www.youtube.com/embed/' . $id,
		);

		$duration = isset( $video['duration'] ) ? (string) $video['duration'] : '';
		if ( self::is_valid_duration( $duration ) ) {
			$node['duration'] = $duration;
		}

		return apply_filters( 'cgn_ytp_schema_video', $node, $video );
	}

	public static function print_json_ld() {
		if ( empty( self::$nodes ) || ! self::is_enabled() || self::is_elementor_preview() ) {
			return;
		}

		$data = array(
			'@context' => 'https://schema.org',
			'@graph'   => array_values( self::$nodes ),
		);

		// JSON_HEX_TAG turns < and > into \u003C / \u003E so a title can never close the script tag.
		$json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG );
		if ( $json ) {
			echo "\n<script type=\"application/ld+json\" class=\"cgn-ytp-schema\">" . $json . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- encoded above.
		}
	}

	/**
	 * Up to three thumbnail URLs, largest first.
	 *
	 * @param array $thumbnails Size => URL.
	 * @return string[]
	 */
	private static function thumbnail_urls( array $thumbnails ) {
		$urls = array();
		foreach ( array( 'maxres', 'standard', 'high', 'medium', 'default' ) as $size ) {
			if ( empty( $thumbnails[ $size ] ) || ! is_string( $thumbnails[ $size ] ) ) {
				continue;
			}
			$url = esc_url_raw( set_url_scheme( $thumbnails[ $size ], 'https' ) );
			if ( $url && ! in_array( $url, $urls, true ) ) {
				$urls[] = $url;
			}
			if ( count( $urls ) >= 3 ) {
				break;
			}
		}
		return $urls;
	}

	/** ISO 8601 date with timezone, or '' if it cannot be parsed. */
	private static function iso_date( $value ) {
		$ts = $value ? strtotime( $value ) : false;
		return $ts ? gmdate( 'c', $ts ) : '';
	}

	/** Accepts ISO 8601 durations like PT12M48S; rejects P0D, which YouTube returns for live streams. */
	private static function is_valid_duration( $value ) {
		return 'P0D' !== $value
			&& (bool) preg_match( '/^P(?!$)(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?$/', $value );
	}

	private static function clean_description( $text ) {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $text ) > self::MAX_DESCRIPTION ) {
			$text = rtrim( mb_substr( $text, 0, self::MAX_DESCRIPTION - 1 ) ) . '…';
		} elseif ( ! function_exists( 'mb_strlen' ) && strlen( $text ) > self::MAX_DESCRIPTION ) {
			$text = rtrim( substr( $text, 0, self::MAX_DESCRIPTION - 3 ) ) . '...';
		}
		return $text;
	}

	/** Skip output inside the Elementor editor. */
	private static function is_elementor_preview() {
		return Plugin::is_editor();
	}
}
