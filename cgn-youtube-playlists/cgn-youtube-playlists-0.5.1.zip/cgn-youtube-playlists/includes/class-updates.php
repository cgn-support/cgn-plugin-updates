<?php
/**
 * Offers plugin updates only while the site's YouTube API key works.
 *
 * The key status comes from Settings: it updates itself from the daily video refresh
 * and is re-checked with YouTube at most every few days. When the key is missing,
 * deleted in Google Cloud, or blocked by its IP restriction (e.g. the site moved to
 * another host), updates are hidden everywhere: the Plugins screen, Dashboard → Updates,
 * auto-updates, and management tools that read WordPress's update list.
 *
 * This is a gate on the site's own update check, not copy protection: the update feed
 * itself is public.
 *
 * @package CGN_YTP
 */

namespace CGN_YTP;

defined( 'ABSPATH' ) || exit;

final class Updates {

	/** @var bool|null Per-request cache of the cheap (no network) check. */
	private static $allowed = null;

	/**
	 * @param object $checker Plugin Update Checker instance.
	 */
	public static function init( $checker ) {
		// At update-check time (already a network moment), allow a fresh key check.
		$checker->addFilter( 'request_update_result', array( __CLASS__, 'filter_update_result' ) );
		$checker->addFilter( 'manual_check_message', array( __CLASS__, 'manual_check_message' ), 10, 2 );

		// Wherever WordPress reads its update list, drop ours if the key isn't active.
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'hide_update' ), 20 );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_meta' ), 10, 2 );
	}

	/**
	 * @param bool $allow_check See Settings::key_is_active().
	 * @return bool
	 */
	public static function allowed( $allow_check = false ) {
		if ( $allow_check ) {
			self::$allowed = null;
		}
		if ( null === self::$allowed ) {
			self::$allowed = (bool) apply_filters( 'cgn_ytp_updates_allowed', Settings::key_is_active( $allow_check ) );
		}
		return self::$allowed;
	}

	/**
	 * @param mixed $update Update found in the feed, or null.
	 * @return mixed
	 */
	public static function filter_update_result( $update ) {
		return self::allowed( true ) ? $update : null;
	}

	/**
	 * @param string $message Message shown after "Check for updates".
	 * @param string $status  no_update, update_available or error.
	 * @return string
	 */
	public static function manual_check_message( $message, $status ) {
		if ( self::allowed() || 'error' === $status ) {
			return $message;
		}
		return esc_html( self::paused_reason() ) . ' ' . sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'options-general.php?page=' . Settings::PAGE ) ),
			esc_html__( 'Open settings', 'cgn-youtube-playlists' )
		);
	}

	/**
	 * @param mixed $transient WordPress's update_plugins site transient.
	 * @return mixed
	 */
	public static function hide_update( $transient ) {
		$file = plugin_basename( CGN_YTP_FILE );
		if ( is_object( $transient ) && isset( $transient->response[ $file ] ) && ! self::allowed() ) {
			unset( $transient->response[ $file ] );
		}
		return $transient;
	}

	/**
	 * Adds a short note under the plugin on the Plugins screen while updates are paused.
	 *
	 * @param string[] $meta Row links.
	 * @param string   $file Plugin file.
	 * @return string[]
	 */
	public static function row_meta( $meta, $file ) {
		if ( plugin_basename( CGN_YTP_FILE ) !== $file || self::allowed() ) {
			return $meta;
		}
		$meta[] = sprintf(
			'<span style="color:#b32d2e">%s</span> <a href="%s">%s</a>',
			esc_html( self::paused_reason() ),
			esc_url( admin_url( 'options-general.php?page=' . Settings::PAGE ) ),
			esc_html__( 'Fix', 'cgn-youtube-playlists' )
		);
		return $meta;
	}

	private static function paused_reason() {
		$state = Settings::get_key_status()['state'];
		if ( 'none' === $state ) {
			return __( 'Updates paused: add a YouTube API key to receive updates.', 'cgn-youtube-playlists' );
		}
		if ( 'invalid' === $state ) {
			return __( "Updates paused: this site's YouTube API key isn't working.", 'cgn-youtube-playlists' );
		}
		return __( "Updates paused until this site's YouTube API key is confirmed.", 'cgn-youtube-playlists' );
	}
}
