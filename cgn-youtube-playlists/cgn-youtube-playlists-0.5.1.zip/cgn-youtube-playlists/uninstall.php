<?php
/**
 * Removes plugin data when the plugin is deleted from the Plugins screen.
 *
 * @package CGN_YTP
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'cgn_ytp_settings' );
delete_option( 'cgn_ytp_key_status' );
delete_option( 'external_updates-cgn-youtube-playlists' ); // Plugin Update Checker's state.

global $wpdb;
$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_cgn_ytp_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_cgn_ytp_' ) . '%',
		$wpdb->esc_like( 'cgn_ytp_bk_' ) . '%'
	)
);
