<?php
/**
 * Plugin Name:       CGN YouTube Playlists
 * Description:       Elementor widget that shows a YouTube channel's playlists as tabs in a grid, carousel or featured-player layout. New videos appear automatically.
 * Version:           0.5.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Requires Plugins:  elementor
 * Author:            Contractor Growth Network
 * Text Domain:       cgn-youtube-playlists
 */

defined( 'ABSPATH' ) || exit;

define( 'CGN_YTP_VERSION', '0.5.1' );
define( 'CGN_YTP_FILE', __FILE__ );
define( 'CGN_YTP_PATH', plugin_dir_path( __FILE__ ) );
define( 'CGN_YTP_URL', plugin_dir_url( __FILE__ ) );

require_once CGN_YTP_PATH . 'includes/class-plugin.php';
require_once CGN_YTP_PATH . 'includes/class-api.php';
require_once CGN_YTP_PATH . 'includes/class-repository.php';
require_once CGN_YTP_PATH . 'includes/class-settings.php';
require_once CGN_YTP_PATH . 'includes/class-schema.php';
require_once CGN_YTP_PATH . 'includes/class-rest.php';
require_once CGN_YTP_PATH . 'includes/class-updates.php';

add_action( 'plugins_loaded', array( 'CGN_YTP\\Plugin', 'instance' ) );

/*
 * Automatic updates from CGN's update feed.
 *
 * The cgn-plugins GitHub repo builds a new package whenever this file's Version
 * header changes and publishes it to the feed. The feed address below is filled
 * in by that build, so copies installed straight from the repo source (where the
 * placeholder is still in place) simply skip update checks.
 * To point a site at a different feed, define CGN_UPDATE_FEED in wp-config.php.
 */
$cgn_ytp_feed = defined( 'CGN_UPDATE_FEED' ) ? CGN_UPDATE_FEED : 'https://cgn-support.github.io/cgn-plugin-updates';
if ( false === strpos( $cgn_ytp_feed, '{{' ) ) {
	require_once CGN_YTP_PATH . 'vendor/plugin-update-checker/plugin-update-checker.php';
	$cgn_ytp_checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		trailingslashit( $cgn_ytp_feed ) . 'cgn-youtube-playlists/info.json',
		__FILE__,
		'cgn-youtube-playlists',
		6 // Check every 6 hours (WordPress's own check is every 12).
	);
	// Updates are only offered while this site's YouTube API key works.
	CGN_YTP\Updates::init( $cgn_ytp_checker );
	unset( $cgn_ytp_checker );
}
unset( $cgn_ytp_feed );
