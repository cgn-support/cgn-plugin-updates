/**
 * CGN YouTube Playlists: carousel layout.
 * Native horizontal scroll with snap points (so touch swipe just works),
 * plus arrows, dots and optional autoplay.
 */
( function () {
	'use strict';

	var reduceMotion = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function setup( carousel, root ) {
		if ( carousel.cgnReady ) {
			return;
		}
		carousel.cgnReady = true;

		var track = carousel.querySelector( '.cgn-ytp__track' );
		var prev = carousel.querySelector( '.cgn-ytp__prev' );
		var next = carousel.querySelector( '.cgn-ytp__next' );
		var dots = carousel.querySelector( '.cgn-ytp__dots' );
		var dotLabel = carousel.getAttribute( 'data-dot-label' ) || 'Go to slide %d';
		if ( ! track ) {
			return;
		}

		function stepWidth() {
			var card = track.querySelector( '.cgn-ytp__card' );
			if ( ! card ) {
				return track.clientWidth || 1;
			}
			var gap = parseFloat( window.getComputedStyle( track ).columnGap ) || 0;
			return card.getBoundingClientRect().width + gap;
		}
		function pageWidth() {
			var step = stepWidth();
			return Math.max( 1, Math.floor( ( track.clientWidth + 2 ) / step ) ) * step;
		}
		function maxScroll() {
			return Math.max( 0, track.scrollWidth - track.clientWidth );
		}
		function pageCount() {
			var max = maxScroll();
			return max <= 2 ? 1 : Math.ceil( max / pageWidth() - 0.01 ) + 1;
		}
		function currentPage() {
			if ( track.scrollLeft >= maxScroll() - 2 ) {
				return pageCount() - 1;
			}
			return Math.round( track.scrollLeft / pageWidth() );
		}
		function goTo( index ) {
			var count = pageCount();
			index = ( ( index % count ) + count ) % count;
			track.scrollTo( { left: Math.min( index * pageWidth(), maxScroll() ), behavior: reduceMotion ? 'auto' : 'smooth' } );
		}

		function update() {
			if ( ! track.clientWidth ) {
				return; // Hidden tab panel; updates again when shown.
			}
			var count = pageCount();
			var current = currentPage();

			if ( prev ) {
				prev.disabled = current <= 0;
			}
			if ( next ) {
				next.disabled = current >= count - 1;
			}
			if ( dots ) {
				if ( dots.children.length !== count ) {
					dots.innerHTML = '';
					for ( var i = 0; i < count; i++ ) {
						var dot = document.createElement( 'button' );
						dot.type = 'button';
						dot.className = 'cgn-ytp__dot';
						dot.setAttribute( 'aria-label', dotLabel.replace( '%d', i + 1 ) );
						dot.addEventListener( 'click', goTo.bind( null, i ) );
						dots.appendChild( dot );
					}
				}
				Array.prototype.forEach.call( dots.children, function ( dot, i ) {
					var on = i === current;
					dot.classList.toggle( 'is-active', on );
					if ( on ) {
						dot.setAttribute( 'aria-current', 'true' );
					} else {
						dot.removeAttribute( 'aria-current' );
					}
				} );
				dots.hidden = count < 2;
			}
		}

		if ( prev ) {
			prev.addEventListener( 'click', function () {
				goTo( currentPage() - 1 );
			} );
		}
		if ( next ) {
			next.addEventListener( 'click', function () {
				goTo( currentPage() + 1 );
			} );
		}

		var frame = 0;
		track.addEventListener( 'scroll', function () {
			window.cancelAnimationFrame( frame );
			frame = window.requestAnimationFrame( update );
		}, { passive: true } );

		if ( window.ResizeObserver ) {
			new window.ResizeObserver( update ).observe( track );
		} else {
			window.addEventListener( 'resize', update );
		}
		root.addEventListener( 'cgnytp:tabchange', function () {
			window.requestAnimationFrame( update );
		} );
		update();

		// Autoplay: pauses on hover or keyboard focus, while a video plays, and when the tab is hidden.
		if ( '1' === root.getAttribute( 'data-autoplay' ) && ! reduceMotion ) {
			var paused = false;
			var delay = Math.max( 2, parseInt( root.getAttribute( 'data-speed' ), 10 ) || 5 ) * 1000;

			carousel.addEventListener( 'mouseenter', function () {
				paused = true;
			} );
			carousel.addEventListener( 'mouseleave', function () {
				paused = false;
			} );
			carousel.addEventListener( 'focusin', function () {
				paused = true;
			} );
			carousel.addEventListener( 'focusout', function ( e ) {
				if ( ! carousel.contains( e.relatedTarget ) ) {
					paused = false;
				}
			} );

			window.setInterval( function () {
				if ( paused || document.hidden || carousel.closest( '[hidden]' ) || carousel.querySelector( '.cgn-ytp__frame' ) ) {
					return;
				}
				goTo( currentPage() + 1 );
			}, delay );
		}
	}

	function plugin( root ) {
		root.querySelectorAll( '.cgn-ytp__carousel' ).forEach( function ( carousel ) {
			setup( carousel, root );
		} );
	}

	var api = window.cgnYtp = window.cgnYtp || {};
	api.plugins = api.plugins || [];
	api.plugins.push( plugin );

	// Widgets already initialized before this file loaded.
	document.querySelectorAll( '.cgn-ytp' ).forEach( function ( root ) {
		if ( root.cgnYtpReady ) {
			plugin( root );
		}
	} );
}() );
