/**
 * Playlist toggle control for the Elementor panel.
 * Saved value: { hidden: [ids], order: [ids], v: timestamp }
 */
( function ( $ ) {
	'use strict';

	var cfg = window.cgnYtpEditor || {};
	var t = cfg.i18n || {};
	var CHANNEL_RE = /^UC[A-Za-z0-9_-]{22}$/;

	function register() {
		var View = elementor.modules.controls.BaseData.extend( {

			onReady: function () {
				var self = this;

				this.$list = this.$el.find( '.cgn-ytp-pl__list' );
				this.$status = this.$el.find( '.cgn-ytp-pl__status' );
				this.$refresh = this.$el.find( '.cgn-ytp-pl__refresh' );
				this.ytpSettings = this.container ? this.container.settings : this.elementSettingsModel;
				this.ytpChannelKey = this.model.get( 'channel_control' ) || 'channel_id';
				this.ytpRequest = null;

				this.listenTo( this.ytpSettings, 'change:' + this.ytpChannelKey, _.debounce( function () {
					self.ytpLoad( false );
				}, 700 ) );

				this.$refresh.on( 'click', function () {
					self.ytpLoad( true );
				} );

				this.$list.on( 'change', 'input[type="checkbox"]', function () {
					$( this ).closest( 'li' ).toggleClass( 'is-off', ! this.checked );
					self.ytpSave();
				} );

				if ( ! $.fn.sortable ) {
					this.ytpLoad( false );
					return;
				}
				this.$list.sortable( {
					handle: '.cgn-ytp-pl__handle',
					axis: 'y',
					tolerance: 'pointer',
					update: function () {
						self.ytpSave();
					}
				} );

				this.ytpLoad( false );
			},

			onBeforeDestroy: function () {
				if ( this.ytpRequest ) {
					this.ytpRequest.abort();
				}
				if ( this.$list && $.fn.sortable && this.$list.sortable( 'instance' ) ) {
					this.$list.sortable( 'destroy' );
				}
			},

			ytpValue: function () {
				var v = this.getControlValue();
				return v && typeof v === 'object' ? v : { hidden: [], order: [] };
			},

			ytpChannel: function () {
				return String( this.ytpSettings.get( this.ytpChannelKey ) || '' ).trim();
			},

			ytpStatus: function ( text, type ) {
				this.$status.attr( 'class', 'cgn-ytp-pl__status is-' + ( type || 'info' ) ).text( text || '' );
			},

			ytpLoad: function ( refresh ) {
				var self = this;
				var channel = this.ytpChannel();

				if ( this.ytpRequest ) {
					this.ytpRequest.abort();
				}

				if ( ! CHANNEL_RE.test( channel ) ) {
					this.$list.empty();
					this.$refresh.prop( 'disabled', true );
					this.ytpStatus( channel ? t.badChannel : t.enterChannel );
					return;
				}

				this.$refresh.prop( 'disabled', true );
				this.ytpStatus( refresh ? t.refreshing : t.loading );

				this.ytpRequest = $.ajax( {
					url: cfg.restUrl,
					method: refresh ? 'POST' : 'GET',
					data: { channel: channel },
					beforeSend: function ( xhr ) {
						xhr.setRequestHeader( 'X-WP-Nonce', cfg.nonce );
					}
				} ).done( function ( res ) {
					self.ytpRender( res );
					if ( refresh ) {
						// Saving a new stamp makes Elementor re-render the widget with the fresh data.
						self.ytpSave( true );
					}
				} ).fail( function ( xhr, textStatus ) {
					if ( 'abort' === textStatus ) {
						return;
					}
					var msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : t.error;
					self.$list.empty();
					self.ytpStatus( msg, 'error' );
				} ).always( function () {
					self.ytpRequest = null;
					self.$refresh.prop( 'disabled', false );
				} );
			},

			ytpRender: function ( res ) {
				var self = this;
				var val = this.ytpValue();
				var hidden = val.hidden || [];
				var order = val.order || [];
				var items = ( res.playlists || [] ).map( function ( p, i ) {
					return $.extend( { yt: i }, p );
				} );

				// Saved order first; playlists not seen before go to the end in YouTube's order.
				items.sort( function ( a, b ) {
					var ia = order.indexOf( a.id );
					var ib = order.indexOf( b.id );
					ia = ia === -1 ? 1e6 + a.yt : ia;
					ib = ib === -1 ? 1e6 + b.yt : ib;
					return ia - ib;
				} );

				this.$list.empty();

				items.forEach( function ( p ) {
					var off = hidden.indexOf( p.id ) !== -1;
					var $li = $( '<li class="cgn-ytp-pl__item"></li>' ).attr( 'data-id', p.id ).toggleClass( 'is-off', off );

					$( '<span class="cgn-ytp-pl__handle eicon-ellipsis-v"></span>' ).attr( 'title', t.drag ).appendTo( $li );

					var $text = $( '<span class="cgn-ytp-pl__text"></span>' ).appendTo( $li );
					$( '<span class="cgn-ytp-pl__name"></span>' ).text( p.title ).appendTo( $text );
					$( '<span class="cgn-ytp-pl__count"></span>' ).text( p.count + ' ' + ( 1 === p.count ? t.video : t.videos ) ).appendTo( $text );

					var $switch = $( '<label class="cgn-ytp-pl__switch"><input type="checkbox"><span></span></label>' ).appendTo( $li );
					$switch.find( 'input' ).prop( 'checked', ! off ).attr( 'aria-label', t.show + ' ' + p.title );

					self.$list.append( $li );
				} );

				if ( ! items.length ) {
					this.ytpStatus( t.none, 'info' );
				} else if ( res.stale ) {
					this.ytpStatus( t.stale, 'error' );
				} else {
					this.ytpStatus(
						( t.summary || '%1$s · %2$s · %3$s' )
							.replace( '%1$s', res.channel_title || '' )
							.replace( '%2$s', items.length )
							.replace( '%3$s', res.fetched_human || '' )
					);
				}
			},

			ytpSave: function ( bump ) {
				var hidden = [];
				var order = [];

				this.$list.children( 'li' ).each( function () {
					var id = $( this ).attr( 'data-id' );
					order.push( id );
					if ( ! $( this ).find( 'input' ).prop( 'checked' ) ) {
						hidden.push( id );
					}
				} );

				var next = { hidden: hidden, order: order, v: this.ytpValue().v || 0 };
				if ( bump ) {
					next.v = Date.now();
				}
				this.setValue( next );
			}
		} );

		elementor.addControlView( 'cgn_ytp_playlists', View );
	}

	// Register now if the editor is already up, otherwise wait for it.
	if ( window.elementor && window.elementor.modules && window.elementor.modules.controls ) {
		register();
	} else {
		$( window ).on( 'elementor:init', register );
	}
}( jQuery ) );
