/**
 * CGN YouTube Playlists: tabs, click-to-play, featured player, load more.
 * Layout add-ons (carousel) register through window.cgnYtp.plugins.
 */
( function () {
	'use strict';

	var EMBED = 'https://www.youtube-nocookie.com/embed/';
	var PLAY_SVG = '<span class="cgn-ytp__play"><svg viewBox="0 0 24 24" focusable="false" aria-hidden="true"><path d="M8 5.5v13l10.5-6.5z"></path></svg></span>';

	var api = window.cgnYtp = window.cgnYtp || {};
	api.plugins = api.plugins || [];

	function makeFrame( id, title, thumb ) {
		var wrap = document.createElement( 'div' );
		var frame = document.createElement( 'iframe' );
		wrap.className = 'cgn-ytp__frame';
		frame.src = EMBED + encodeURIComponent( id ) + '?autoplay=1&rel=0&playsinline=1';
		frame.title = title || 'YouTube video';
		frame.setAttribute( 'allow', 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' );
		frame.setAttribute( 'allowfullscreen', '' );
		frame.setAttribute( 'referrerpolicy', 'strict-origin-when-cross-origin' );
		wrap.appendChild( frame );
		wrap.cgnThumb = thumb || null;
		return wrap;
	}

	/** Puts every playing video in this widget back to its thumbnail. */
	function stopAll( root ) {
		root.querySelectorAll( '.cgn-ytp__frame' ).forEach( function ( wrap ) {
			if ( wrap.cgnThumb && wrap.parentNode ) {
				wrap.parentNode.replaceChild( wrap.cgnThumb, wrap );
			}
		} );
	}

	function playInline( root, thumb ) {
		stopAll( root );
		var label = thumb.getAttribute( 'aria-label' ) || '';
		var frame = makeFrame( thumb.getAttribute( 'data-video' ), label, thumb );
		thumb.parentNode.replaceChild( frame, thumb );
		frame.querySelector( 'iframe' ).focus();
	}

	function activateTab( root, tab, focus ) {
		var list = tab.parentNode;
		root.querySelectorAll( '.cgn-ytp__tab' ).forEach( function ( t ) {
			var on = t === tab;
			var panel = document.getElementById( t.getAttribute( 'aria-controls' ) );
			t.classList.toggle( 'is-active', on );
			t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
			t.tabIndex = on ? 0 : -1;
			if ( panel ) {
				panel.hidden = ! on;
			}
		} );
		stopAll( root );

		if ( list.scrollWidth > list.clientWidth ) {
			list.scrollTo( { left: Math.max( 0, tab.offsetLeft - 24 ), behavior: 'smooth' } );
		}
		if ( focus ) {
			tab.focus();
		}
		root.dispatchEvent( new CustomEvent( 'cgnytp:tabchange' ) );
	}

	function onTabKey( root, e ) {
		var tabs = Array.prototype.slice.call( root.querySelectorAll( '.cgn-ytp__tab' ) );
		var i = tabs.indexOf( e.target );
		if ( i === -1 ) {
			return;
		}
		var next = null;
		if ( 'ArrowRight' === e.key ) {
			next = tabs[ ( i + 1 ) % tabs.length ];
		} else if ( 'ArrowLeft' === e.key ) {
			next = tabs[ ( i - 1 + tabs.length ) % tabs.length ];
		} else if ( 'Home' === e.key ) {
			next = tabs[ 0 ];
		} else if ( 'End' === e.key ) {
			next = tabs[ tabs.length - 1 ];
		}
		if ( next ) {
			e.preventDefault();
			activateTab( root, next, true );
		}
	}

	function loadMore( button ) {
		var panel = button.closest( '.cgn-ytp__panel' );
		var step = parseInt( button.getAttribute( 'data-step' ), 10 ) || 6;
		var waiting = panel.querySelectorAll( '.cgn-ytp__card.is-more[hidden]' );
		var first = null;

		for ( var i = 0; i < waiting.length && i < step; i++ ) {
			waiting[ i ].hidden = false;
			first = first || waiting[ i ];
		}
		if ( waiting.length <= step ) {
			button.parentNode.remove();
		}
		if ( first ) {
			var thumb = first.querySelector( '.cgn-ytp__thumb' );
			if ( thumb ) {
				thumb.focus();
			}
		}
	}

	function bigThumb( item ) {
		var button = document.createElement( 'button' );
		var img = item.querySelector( 'img' );
		button.type = 'button';
		button.className = 'cgn-ytp__thumb cgn-ytp__thumb--lg';
		button.setAttribute( 'data-video', item.getAttribute( 'data-video' ) );
		button.setAttribute( 'aria-label', item.getAttribute( 'data-label' ) || '' );
		if ( img ) {
			var copy = img.cloneNode( false );
			copy.setAttribute( 'sizes', '(max-width: 767px) 100vw, 66vw' );
			copy.removeAttribute( 'loading' );
			button.appendChild( copy );
		}
		button.insertAdjacentHTML( 'beforeend', PLAY_SVG );
		var duration = item.querySelector( '.cgn-ytp__duration' );
		if ( duration ) {
			button.appendChild( duration.cloneNode( true ) );
		}
		return button;
	}

	function selectItem( root, item ) {
		var featured = item.closest( '.cgn-ytp__featured' );
		var player = featured.querySelector( '.cgn-ytp__player' );

		featured.querySelectorAll( '.cgn-ytp__item' ).forEach( function ( b ) {
			var on = b === item;
			b.classList.toggle( 'is-active', on );
			if ( on ) {
				b.setAttribute( 'aria-current', 'true' );
			} else {
				b.removeAttribute( 'aria-current' );
			}
		} );

		stopAll( root );
		player.innerHTML = '';
		player.appendChild( makeFrame( item.getAttribute( 'data-video' ), item.getAttribute( 'data-label' ), bigThumb( item ) ) );

		var set = function ( selector, attr ) {
			var el = featured.querySelector( selector );
			if ( el ) {
				el.textContent = item.getAttribute( attr ) || '';
			}
		};
		set( '.cgn-ytp__now-title', 'data-title' );
		set( '.cgn-ytp__now-meta', 'data-meta' );
		set( '.cgn-ytp__now-desc', 'data-desc' );

		if ( window.matchMedia( '(max-width: 767px)' ).matches ) {
			player.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		}
	}

	function init( root ) {
		if ( ! root || root.cgnYtpReady ) {
			return;
		}
		root.cgnYtpReady = true;

		root.addEventListener( 'click', function ( e ) {
			var target = e.target;
			var thumb = target.closest( '.cgn-ytp__thumb' );
			if ( thumb ) {
				playInline( root, thumb );
				return;
			}
			var item = target.closest( '.cgn-ytp__item' );
			if ( item ) {
				selectItem( root, item );
				return;
			}
			var tab = target.closest( '.cgn-ytp__tab' );
			if ( tab ) {
				activateTab( root, tab, false );
				return;
			}
			var more = target.closest( '.cgn-ytp__more' );
			if ( more ) {
				loadMore( more );
			}
		} );

		var tablist = root.querySelector( '.cgn-ytp__tabs' );
		if ( tablist ) {
			tablist.addEventListener( 'keydown', function ( e ) {
				onTabKey( root, e );
			} );
		}

		api.plugins.forEach( function ( plugin ) {
			plugin( root );
		} );
	}

	api.init = init;
	api.initAll = function ( scope ) {
		( scope || document ).querySelectorAll( '.cgn-ytp' ).forEach( init );
	};

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			api.initAll();
		} );
	} else {
		api.initAll();
	}

	// Elementor editor: widgets re-render in place, so re-init each time one is ready.
	function hookElementor() {
		if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
			window.elementorFrontend.hooks.addAction( 'frontend/element_ready/cgn_youtube_playlists.default', function ( $scope ) {
				api.initAll( $scope[ 0 ] );
			} );
			return true;
		}
		return false;
	}
	if ( ! hookElementor() && window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', hookElementor );
	}
}() );
