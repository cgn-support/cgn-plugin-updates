## 0.5.1
- Tab alignment option (left, center, right or full width) under Style → Tabs, settable per breakpoint.

## 0.5.0
- Updates are only offered while the site's YouTube API key works. The Plugins screen shows why when they're paused.
- The API key status now keeps itself current from the daily video refresh, so a deleted or blocked key is noticed automatically.

## 0.4.0
- Automatic updates: new versions now appear on the Plugins screen like any other plugin.

## 0.3.2
- Style controls for the "Load more" button: alignment, spacing, typography, colors (normal and hover), border and padding.

## 0.3.1
- Fixed the Playlists panel going blank in the Elementor editor.
- Removed the widget header (eyebrow and heading).

## 0.3.0
- Elementor widget with grid, carousel and featured-player layouts.
- Playlist toggles with drag-to-reorder in the editor.

## 0.2.0
- YouTube data layer with a daily cache and last-good-copy backup.
- API key status display and "Test a channel" tool on the settings screen.

## 0.1.0
- Plugin scaffold, settings screen and VideoObject structured data.
